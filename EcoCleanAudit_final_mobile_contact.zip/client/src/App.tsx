import React, { Suspense, lazy } from "react";
import { BrowserRouter as Router, Routes, Route, Navigate } from "react-router-dom";
import useMobile from "./hooks/use-mobile";
const MobileDashboard = lazy(() => import("./pages/mobile-dashboard"));
const Dashboard = lazy(() => import("./pages/dashboard"));
const NotFound = lazy(() => import("./pages/not-found"));
const Workspace = lazy(() => import("./pages/workspace"));

export default function App() {
  const isMobile = useMobile();

  return (
    <Router>
      <Suspense fallback={<div className='min-h-screen flex items-center justify-center'>Loading…</div>}>
        <Routes>
          <Route path='/' element={isMobile ? <MobileDashboard /> : <Dashboard />} />
          <Route path='/dashboard' element={<Dashboard />} />
          <Route path='/workspace' element={<Workspace />} />
          <Route path='/mobile' element={<MobileDashboard />} />
          <Route path='*' element={<NotFound />} />
        </Routes>
      </Suspense>
    </Router>
  );
}
