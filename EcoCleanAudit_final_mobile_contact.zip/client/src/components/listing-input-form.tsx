import { useState } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { useMutation } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import { listingSchema, type Listing, type AnalysisResult } from "@shared/schema";
import { Plus, Loader2 } from "lucide-react";

interface ListingInputFormProps {
  onAnalysisStart: () => void;
  onAnalysisComplete: (result: AnalysisResult) => void;
  onAnalysisError: () => void;
  isAnalyzing: boolean;
}

const categories = [
  "Household Cleaners",
  "Dietary Supplements", 
  "Pet Products",
  "Personal Care",
  "Home & Garden"
];

export default function ListingInputForm({ 
  onAnalysisStart, 
  onAnalysisComplete, 
  onAnalysisError,
  isAnalyzing 
}: ListingInputFormProps) {
  const { toast } = useToast();
  const [bulletPoints, setBulletPoints] = useState<string[]>(["", "", ""]);

  const form = useForm<Listing>({
    resolver: zodResolver(listingSchema),
    defaultValues: {
      category: "Household Cleaners",
      title: "",
      bullets: ["", "", ""],
      description: ""
    }
  });

  const auditMutation = useMutation({
    mutationFn: async (listing: Listing) => {
      const response = await apiRequest("POST", "/api/audit", listing);
      return await response.json();
    },
    onSuccess: (result: AnalysisResult) => {
      onAnalysisComplete(result);
      toast({
        title: "Analysis Complete",
        description: `Found ${result.summary.total} violation${result.summary.total !== 1 ? 's' : ''}`,
      });
    },
    onError: (error: Error) => {
      onAnalysisError();
      toast({
        title: "Analysis Failed",
        description: error.message || "Failed to analyze listing. Please try again.",
        variant: "destructive",
      });
    }
  });

  const onSubmit = (data: Listing) => {
    // Filter out empty bullet points
    const filteredBullets = data.bullets.filter(bullet => bullet.trim() !== "");
    const listing = { ...data, bullets: filteredBullets };
    
    onAnalysisStart();
    auditMutation.mutate(listing);
  };

  const addBulletPoint = () => {
    setBulletPoints([...bulletPoints, ""]);
    const currentBullets = form.getValues("bullets");
    form.setValue("bullets", [...currentBullets, ""]);
  };

  const updateBulletPoint = (index: number, value: string) => {
    const newBullets = [...bulletPoints];
    newBullets[index] = value;
    setBulletPoints(newBullets);
    form.setValue("bullets", newBullets);
  };

  const clearForm = () => {
    form.reset();
    setBulletPoints(["", "", ""]);
  };

  return (
    <div className="space-y-6">
      <div className="bg-white rounded-lg shadow-sm border border-slate-200 p-6">
        <h2 className="text-lg font-semibold text-slate-900 mb-4">Listing Details</h2>
        
        <Form {...form}>
          <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
            {/* Category Selection */}
            <FormField
              control={form.control}
              name="category"
              render={({ field }) => (
                <FormItem>
                  <FormLabel className="text-sm font-medium text-slate-700">Product Category</FormLabel>
                  <Select onValueChange={field.onChange} defaultValue={field.value}>
                    <FormControl>
                      <SelectTrigger className="bg-white border-slate-300 focus:border-brand-blue focus:ring-brand-blue">
                        <SelectValue placeholder="Select category" />
                      </SelectTrigger>
                    </FormControl>
                    <SelectContent>
                      {categories.map((category) => (
                        <SelectItem key={category} value={category}>
                          {category}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                  <FormMessage />
                </FormItem>
              )}
            />

            {/* Title Input */}
            <FormField
              control={form.control}
              name="title"
              render={({ field }) => (
                <FormItem>
                  <FormLabel className="text-sm font-medium text-slate-700">Product Title</FormLabel>
                  <FormControl>
                    <Input 
                      {...field}
                      placeholder="Enter product title..."
                      className="border-slate-300 focus:border-brand-blue focus:ring-brand-blue"
                    />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />

            {/* Bullet Points */}
            <div>
              <FormLabel className="text-sm font-medium text-slate-700 mb-2 block">Bullet Points</FormLabel>
              <div className="space-y-3">
                {bulletPoints.map((bullet, index) => (
                  <Input
                    key={index}
                    value={bullet}
                    onChange={(e) => updateBulletPoint(index, e.target.value)}
                    placeholder={`Bullet point ${index + 1}...`}
                    className="border-slate-300 focus:border-brand-blue focus:ring-brand-blue"
                  />
                ))}
                <Button
                  type="button"
                  variant="ghost"
                  onClick={addBulletPoint}
                  className="text-brand-blue hover:text-blue-700 hover:bg-blue-50 p-0 h-auto font-medium"
                >
                  <Plus className="h-4 w-4 mr-1" />
                  Add bullet point
                </Button>
              </div>
            </div>

            {/* Description */}
            <FormField
              control={form.control}
              name="description"
              render={({ field }) => (
                <FormItem>
                  <FormLabel className="text-sm font-medium text-slate-700">Product Description</FormLabel>
                  <FormControl>
                    <Textarea 
                      {...field}
                      placeholder="Enter product description..."
                      rows={6}
                      className="border-slate-300 focus:border-brand-blue focus:ring-brand-blue resize-none"
                    />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />

            {/* Action Buttons */}
            <div className="flex space-x-4">
              <Button
                type="submit"
                disabled={isAnalyzing}
                className="flex-1 bg-brand-blue hover:bg-blue-600 text-white font-medium"
              >
                {isAnalyzing ? (
                  <>
                    <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                    Analyzing...
                  </>
                ) : (
                  "Analyze Listing"
                )}
              </Button>
              <Button
                type="button"
                variant="outline"
                onClick={clearForm}
                disabled={isAnalyzing}
                className="border-slate-300 text-slate-700 hover:bg-slate-50"
              >
                Clear Form
              </Button>
            </div>
          </form>
        </Form>
      </div>

      {/* Analysis Status */}
      {isAnalyzing && (
        <div className="bg-white rounded-lg shadow-sm border border-slate-200 p-4">
          <div className="flex items-center">
            <Loader2 className="h-5 w-5 animate-spin text-brand-blue mr-3" />
            <span className="text-sm text-slate-700">Analyzing listing for compliance violations...</span>
          </div>
        </div>
      )}
    </div>
  );
}
