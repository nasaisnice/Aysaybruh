import React, { useEffect, useState } from "react";
import ContactModal from "../components/contact-modal";

export default function Workspace() {
  const [listings, setListings] = useState<any[]>([]);
  const [selected, setSelected] = useState<any>(null);
  const [open, setOpen] = useState(false);
  const [sseMessages, setSseMessages] = useState<any[]>([]);

  useEffect(()=> {
    fetch("/api/listings?limit=20").then(r=>r.json()).then(d=>{
      if (d && d.data) setListings(d.data);
    });

    // SSE
    const evt = new EventSource(`/api/sse/stream?clientId=workspace_${Math.random().toString(36).slice(2)}`);
    evt.addEventListener("connected", (e:any) => console.log("sse connected", e));
    evt.addEventListener("message", (e:any) => {
      try { const payload = JSON.parse(e.data); setSseMessages(s=>[payload,...s]); } catch {}
    });
    evt.addEventListener("outreach_created", (e:any) => {
      try { const payload = JSON.parse(e.data); setSseMessages(s=>[{type:'outreach',...payload},...s]); } catch {}
    });
    return ()=> evt.close();
  },[]);

  return (
    <div className="min-h-screen p-4 bg-slate-50">
      <div className="max-w-6xl mx-auto grid grid-cols-1 md:grid-cols-4 gap-4">
        <aside className="md:col-span-1 bg-white rounded-xl p-3 shadow">
          <div className="flex items-center justify-between mb-3">
            <h2 className="text-sm font-semibold">Sellers</h2>
            <button className="text-xs">Filter</button>
          </div>
          <div className="space-y-2 max-h-[70vh] overflow-auto">
            {listings.map(l => (
              <button key={l.id} className={`w-full text-left p-2 rounded ${selected?.id===l.id?'bg-slate-100':''}`} onClick={()=>setSelected(l)}>
                <div className="font-medium">{l.title || l.name || "Listing"}</div>
                <div className="text-xs text-slate-500">{l.location || l.city}</div>
              </button>
            ))}
          </div>
        </aside>

        <main className="md:col-span-2 bg-white rounded-xl p-4 shadow min-h-[60vh]">
          {selected ? (
            <>
              <div className="flex items-start justify-between">
                <div>
                  <h3 className="text-lg font-semibold">{selected.title || selected.name}</h3>
                  <div className="text-sm text-slate-500">{selected.location}</div>
                </div>
                <div className="flex gap-2">
                  <button onClick={()=>setOpen(true)} className="px-3 py-2 bg-sky-600 text-white rounded">Contact</button>
                  <button className="px-3 py-2 border rounded">Actions</button>
                </div>
              </div>

              <section className="mt-4">
                <h4 className="text-sm font-medium mb-2">Conversation</h4>
                <div className="h-64 overflow-auto border rounded p-3 text-sm text-slate-700">
                  {sseMessages.length===0 ? <div className="text-slate-400">No messages yet</div> : (
                    sseMessages.map((m, i) => <div key={i} className="mb-2">
                      <div className="text-xs text-slate-500">{m.type || m.channel || "msg"}</div>
                      <div>{m.body || JSON.stringify(m)}</div>
                    </div>)
                  )}
                </div>
              </section>
            </>
          ) : (
            <div className="text-slate-500">Select a seller to view details</div>
          )}
        </main>

        <aside className="md:col-span-1 bg-white rounded-xl p-4 shadow">
          <h4 className="text-sm font-semibold">Profile & Notes</h4>
          {selected ? (
            <>
              <div className="mt-3 text-sm">{selected.description || "No description"}</div>
              <div className="mt-3">
                <h5 className="text-xs font-semibold">Recent Outreach</h5>
                <RecentOutreach listingId={selected.id} />
              </div>
            </>
          ) : <div className="text-slate-400">No seller selected</div>}
        </aside>
      </div>

      <ContactModal open={open} onClose={()=>setOpen(false)} listingId={selected?.id} seller={selected?.seller || {email: selected?.contactEmail}} />
    </div>
  );
}

function RecentOutreach({ listingId }: any) {
  const [items, setItems] = useState<any[]>([]);
  useEffect(()=> {
    if (!listingId) return;
    fetch(`/api/outreach/${listingId}`).then(r=>r.json()).then(d=>{
      if (d && d.data) setItems(d.data);
    });
  }, [listingId]);
  if (!listingId) return null;
  return (
    <div className="mt-2 space-y-2 text-sm">
      {items.length===0 ? <div className="text-slate-400">No outreach yet</div> : items.map(it => (
        <div key={it.id} className="p-2 border rounded">
          <div className="text-xs text-slate-500">{it.channel} • {new Date(it.createdAt).toLocaleString()}</div>
          <div className="text-sm">{it.subject || it.body?.slice(0,80)}</div>
        </div>
      ))}
    </div>
  );
}
