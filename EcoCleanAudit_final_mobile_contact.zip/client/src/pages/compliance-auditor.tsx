import { useState } from "react";
import ListingInputForm from "@/components/listing-input-form";
import ComplianceResults from "@/components/compliance-results";
import type { Listing, AnalysisResult } from "@shared/schema";

export default function ComplianceAuditor() {
  const [analysisResult, setAnalysisResult] = useState<AnalysisResult | null>(null);
  const [isAnalyzing, setIsAnalyzing] = useState(false);

  const handleAnalysisComplete = (result: AnalysisResult) => {
    setAnalysisResult(result);
    setIsAnalyzing(false);
  };

  const handleAnalysisStart = () => {
    setIsAnalyzing(true);
  };

  const handleAnalysisError = () => {
    setIsAnalyzing(false);
  };

  return (
    <div className="bg-slate-50 min-h-screen">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          <ListingInputForm 
            onAnalysisStart={handleAnalysisStart}
            onAnalysisComplete={handleAnalysisComplete}
            onAnalysisError={handleAnalysisError}
            isAnalyzing={isAnalyzing}
          />
          <ComplianceResults 
            result={analysisResult}
            isAnalyzing={isAnalyzing}
          />
        </div>
      </div>

      {/* Footer */}
      <footer className="bg-white border-t border-slate-200 mt-12">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
          <div className="flex justify-between items-center text-sm text-slate-500">
            <div>
              <p>Amazon Listing Compliance Auditor v2.1</p>
              <p>Last policy update: December 2024</p>
            </div>
            <div className="flex space-x-6">
              <a href="#" className="hover:text-slate-700 transition-colors">Documentation</a>
              <a href="#" className="hover:text-slate-700 transition-colors">API Guide</a>
              <a href="#" className="hover:text-slate-700 transition-colors">Support</a>
            </div>
          </div>
        </div>
      </footer>
    </div>
  );
}
