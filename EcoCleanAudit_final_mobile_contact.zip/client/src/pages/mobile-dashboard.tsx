import React from "react";

export default function MobileDashboard() {
  return (
    <main className="min-h-screen bg-gradient-to-b from-white via-slate-50 to-white text-slate-900 p-4">
      <header className="flex items-center justify-between mb-4">
        <h1 className="text-xl font-bold">EcoClean • Audits</h1>
        <button className="p-2 rounded-lg border border-gray-200 bg-white/60 backdrop-blur-sm">
          Menu
        </button>
      </header>

      <section className="space-y-3">
        <div className="rounded-xl p-4 bg-white/70 backdrop-blur-sm border border-gray-200 shadow-sm">
          <div className="flex items-center justify-between">
            <div>
              <h2 className="text-lg font-semibold">Today's Inspections</h2>
              <p className="text-sm text-slate-500 mt-1">3 sites pending</p>
            </div>
            <div className="text-xs text-slate-600">Updated 10m</div>
          </div>

          <ul className="mt-3 space-y-2">
            <li className="flex items-center justify-between">
              <div>
                <div className="font-medium">Site: Harbor Laundry</div>
                <div className="text-xs text-slate-500">NY, 7th St</div>
              </div>
              <div className="text-sm text-amber-600 font-semibold">Warning</div>
            </li>
            <li className="flex items-center justify-between">
              <div>
                <div className="font-medium">Site: GreenWash</div>
                <div className="text-xs text-slate-500">NJ, West</div>
              </div>
              <div className="text-sm text-emerald-600 font-semibold">OK</div>
            </li>
          </ul>
        </div>

        <div className="rounded-xl p-4 bg-white/70 backdrop-blur-sm border border-gray-200 shadow-sm">
          <h3 className="text-sm font-semibold">Quick Actions</h3>
          <div className="mt-3 flex gap-2">
            <button className="flex-1 py-2 rounded-md border border-gray-200">New Audit</button>
            <button className="flex-1 py-2 rounded-md border border-gray-200">Scan</button>
          </div>
        </div>
      </section>

      <nav className="fixed bottom-4 left-1/2 -translate-x-1/2 w-[92%] bg-white/80 backdrop-blur-sm border border-gray-200 rounded-xl p-2 flex justify-around">
        <button className="text-sm">Home</button>
        <button className="text-sm">Audits</button>
        <button className="text-sm">Teams</button>
        <button className="text-sm">Account</button>
      </nav>
    </main>
  );
}
