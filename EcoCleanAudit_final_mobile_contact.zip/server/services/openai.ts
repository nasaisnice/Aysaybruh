import OpenAI from "openai";
import type { Listing, AnalysisResult } from "@shared/schema";

// the newest OpenAI model is "gpt-4o" which was released May 13, 2024. do not change this unless explicitly requested by the user
if (!process.env.OPENAI_API_KEY) {
  throw new Error("OPENAI_API_KEY environment variable is required");
}

const openai = new OpenAI({ 
  apiKey: process.env.OPENAI_API_KEY
});

const SYSTEM_PROMPT = `
You are a professional compliance auditor for Amazon listings in the US marketplace.

Your job is to detect and explain violations based on:
- Amazon's product listing policies
- FDA and FTC advertising guidelines
- General marketplace standards for consumer safety and truth in labeling

You must return structured, actionable audit results in JSON format only. Do not include commentary or extra text outside the JSON.

Be strict, objective, and concise. Flag only genuine violations.
`;

const USER_PROMPT_TEMPLATE = `
Audit the following Amazon listing for compliance violations.

Category: {category}
Title: {title}
Bullet Points:
{bullets}

Description:
{description}

Return a JSON array of violations. Each violation must include:

- "claim_text": The exact phrase or claim that violates policy  
- "rule_violated": The specific Amazon/FDA/FTC rule or principle being broken  
- "why_it_fails": A short explanation of why this claim is non-compliant  
- "severity": One of ["low", "moderate", "high", "critical"]  
- "corrective_copy": A compliant rewrite of the claim  
- "required_evidence_or_doc": What documentation would be needed to justify the original claim  
- "suggested_label_change": If applicable, what should be changed on the product label

If no violations are found, return: []
Do not include any commentary or explanation outside the JSON.
`;

const CATEGORY_RULES = {
  "Household Cleaners": "Flag any unsubstantiated disinfectant, antibacterial, or virus-killing claims unless backed by EPA registration or FDA approval.",
  "Dietary Supplements": "Flag any disease treatment claims, weight loss promises, or unverified health benefits.",
  "Pet Products": "Flag any human-grade claims, medical benefits, or safety guarantees without supporting documentation."
};

function buildAuditPrompt(listing: Listing): string {
  const bullets = listing.bullets.join("\n");
  let basePrompt = USER_PROMPT_TEMPLATE
    .replace("{category}", listing.category)
    .replace("{title}", listing.title)
    .replace("{bullets}", bullets)
    .replace("{description}", listing.description);

  if (listing.category in CATEGORY_RULES) {
    basePrompt += `\n\nCategory-Specific Rule:\n${CATEGORY_RULES[listing.category as keyof typeof CATEGORY_RULES]}`;
  }

  return basePrompt;
}

export async function runComplianceAudit(listing: Listing): Promise<AnalysisResult> {
  try {
    const userPrompt = buildAuditPrompt(listing);

    const response = await openai.chat.completions.create({
      model: "gpt-4o",
      messages: [
        { role: "system", content: SYSTEM_PROMPT },
        { role: "user", content: userPrompt }
      ],
      response_format: { type: "json_object" },
      temperature: 0.3
    });

    const content = response.choices[0].message.content;
    if (!content) {
      throw new Error("No response from OpenAI");
    }

    // Parse the JSON response
    let violations;
    try {
      const parsed = JSON.parse(content);
      violations = Array.isArray(parsed) ? parsed : parsed.violations || [];
    } catch (parseError) {
      throw new Error("Invalid JSON response from OpenAI");
    }

    // Calculate summary
    const summary = {
      total: violations.length,
      critical: violations.filter((v: any) => v.severity === "critical").length,
      high: violations.filter((v: any) => v.severity === "high").length,
      moderate: violations.filter((v: any) => v.severity === "moderate").length,
      low: violations.filter((v: any) => v.severity === "low").length,
      compliant: violations.length === 0
    };

    return {
      violations,
      summary
    };
  } catch (error) {
    throw new Error(`Compliance audit failed: ${error instanceof Error ? error.message : 'Unknown error'}`);
  }
}
