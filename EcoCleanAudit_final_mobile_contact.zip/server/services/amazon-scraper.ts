import type { AmazonProduct, AmazonSearch } from "@shared/schema";
import { RainforestAPI } from "./amazon-api";

// Amazon search scraper service
export class AmazonScraper {
  private baseUrl = "https://www.amazon.com";
  private rainforestAPI = new RainforestAPI();
  
  async searchProducts(searchParams: AmazonSearch): Promise<AmazonProduct[]> {
    const { keywords, category, maxResults } = searchParams;
    
    try {
      console.log(`Searching Amazon for: "${keywords}" using Rainforest API`);
      
      // First try Rainforest API for real data
      const rainforestResults = await this.rainforestAPI.searchProducts(keywords, {
        category_id: this.mapCategoryToAmazonId(category),
        max_page: 1
      });
      
      if (rainforestResults && rainforestResults.length > 0) {
        console.log(`Found ${rainforestResults.length} real products from Rainforest API`);
        return this.convertRainforestToProducts(rainforestResults, maxResults);
      }
      
      // Fallback to direct scraping if Rainforest API fails
      return await this.fallbackDirectScraping(keywords, category, maxResults);
      
    } catch (error) {
      console.error("Amazon search error:", error);
      
      // If Rainforest API is not configured, try direct scraping
      if (error.message.includes('Rainforest API key not configured')) {
        console.log("Rainforest API not available, attempting direct scraping...");
        return await this.fallbackDirectScraping(keywords, category, maxResults);
      }
      
      throw error;
    }
  }

  private async fallbackDirectScraping(keywords: string, category: string | undefined, maxResults: number): Promise<AmazonProduct[]> {
    try {
      // Build search URL
      const searchUrl = this.buildSearchUrl(keywords, category);
      
      // Fetch search results page
      const response = await fetch(searchUrl, {
        headers: {
          'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36',
          'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8',
          'Accept-Language': 'en-US,en;q=0.5',
          'Accept-Encoding': 'gzip, deflate, br',
          'DNT': '1',
          'Connection': 'keep-alive',
          'Upgrade-Insecure-Requests': '1',
        }
      });

      if (!response.ok) {
        throw new Error(`Amazon search failed: ${response.status}. Consider using Rainforest API for reliable access.`);
      }

      const html = await response.text();
      return this.parseSearchResults(html, maxResults);
    } catch (error) {
      throw new Error(`Failed to search Amazon: ${error instanceof Error ? error.message : 'Unknown error'}`);
    }
  }

  private buildSearchUrl(keywords: string, category?: string): string {
    const params = new URLSearchParams({
      k: keywords,
      ref: "sr_pg_1"
    });

    if (category) {
      // Map categories to Amazon search departments
      const categoryMap: Record<string, string> = {
        "Household Cleaners": "garden",
        "Dietary Supplements": "hpc",
        "Pet Products": "pets",
        "Personal Care": "hpc",
        "Home & Garden": "garden"
      };
      
      if (categoryMap[category]) {
        params.append("rh", `n:${categoryMap[category]}`);
      }
    }

    return `${this.baseUrl}/s?${params.toString()}`;
  }

  private convertRainforestToProducts(rainforestResults: any[], maxResults: number): AmazonProduct[] {
    const products: AmazonProduct[] = [];
    
    for (let i = 0; i < Math.min(rainforestResults.length, maxResults); i++) {
      const item = rainforestResults[i];
      
      if (item && item.asin) {
        products.push({
          asin: item.asin,
          title: item.title || 'Unknown Product',
          url: item.link || `https://amazon.com/dp/${item.asin}`,
          bullets: this.extractBulletsFromRainforest(item),
          description: item.description || '',
          category: item.department || 'Unknown Category',
          price: item.price?.value ? `$${item.price.value}` : undefined,
          rating: item.rating,
          reviewCount: item.reviews_count,
          imageUrl: item.image
        });
      }
    }
    
    return products;
  }

  private extractBulletsFromRainforest(item: any): string[] {
    // Extract feature bullets from Rainforest API response
    if (item.feature_bullets && Array.isArray(item.feature_bullets)) {
      return item.feature_bullets;
    }
    
    if (item.features && Array.isArray(item.features)) {
      return item.features;
    }
    
    // Fallback to description if no bullets available
    if (item.description) {
      return [item.description];
    }
    
    return [];
  }

  private mapCategoryToAmazonId(category?: string): string | undefined {
    const categoryMap: Record<string, string> = {
      "Health & Personal Care": "3760901",
      "Electronics": "172282",
      "Home & Garden": "1055398",
      "Baby & Child Care": "165796011",
      "Sports & Outdoors": "3375251",
      "Beauty & Personal Care": "3760901",
      "Automotive": "15690151"
    };
    
    return category ? categoryMap[category] : undefined;
  }

  private generateDemoData(keywords: string, maxResults: number): AmazonProduct[] {
    const products: AmazonProduct[] = [];
    const categories = ["Health & Personal Care", "Electronics", "Home & Garden", "Baby & Child Care"];
    
    for (let i = 0; i < Math.min(maxResults, 20); i++) {
      const category = categories[i % categories.length];
      products.push({
        asin: `B0${Math.random().toString(36).substr(2, 8).toUpperCase()}`,
        title: this.generateRealisticTitle(keywords, category, i),
        url: `https://amazon.com/dp/B0${Math.random().toString(36).substr(2, 8).toUpperCase()}`,
        bullets: this.generateRealisticBullets(keywords, category),
        description: this.generateRealisticDescription(keywords, category),
        category,
        price: `$${(Math.random() * 50 + 10).toFixed(2)}`,
        rating: Math.round((Math.random() * 2 + 3) * 10) / 10,
        reviewCount: Math.floor(Math.random() * 1000 + 50),
        imageUrl: `https://m.media-amazon.com/images/I/sample${i}.jpg`
      });
    }
    
    return products;
  }

  private generateRealisticTitle(keywords: string, category: string, index: number): string {
    const problematicClaims = [
      "FDA Approved",
      "Kills 99.9% of Germs", 
      "Prevents COVID-19",
      "Medical Grade",
      "Doctor Recommended",
      "Hospital Grade",
      "Clinically Proven",
      "100% Natural"
    ];
    
    const baseTitles = {
      "Health & Personal Care": [
        `${keywords} Hand Sanitizer - ${problematicClaims[index % problematicClaims.length]}`,
        `Professional ${keywords} Solution - Instant Germ Protection`,
        `${keywords} Antibacterial Gel - Kills All Viruses Instantly`
      ],
      "Electronics": [
        `${keywords} Device - Military Grade Protection`,
        `Professional ${keywords} Equipment - FCC Certified`, 
        `${keywords} Technology - Blocks 100% EMF Radiation`
      ],
      "Home & Garden": [
        `${keywords} Organic Solution - EPA Approved Formula`,
        `${keywords} Natural Cleaner - Chemical Free Guarantee`,
        `Professional ${keywords} Treatment - Eliminates All Pests`
      ],
      "Baby & Child Care": [
        `${keywords} Baby Formula - Pediatrician Approved`,
        `${keywords} for Babies - 100% Safe and Hypoallergenic`,
        `${keywords} Kids Product - Dermatologist Tested`
      ]
    };
    
    const titles = baseTitles[category] || [`${keywords} Product ${index + 1}`];
    return titles[index % titles.length];
  }

  private generateRealisticBullets(keywords: string, category: string): string[] {
    const problematicBullets = {
      "Health & Personal Care": [
        "FDA approved and doctor recommended formula",
        "Kills 99.9% of all germs and viruses instantly", 
        "Prevents COVID-19 and all diseases",
        "Medical grade quality used in hospitals",
        "Scientifically proven to eliminate 100% of bacteria"
      ],
      "Electronics": [
        "FCC approved and government tested",
        "Military grade durability and strength",
        "Blocks 100% of harmful EMF radiation", 
        "Professional quality used by experts",
        "Lifetime guarantee - never breaks"
      ],
      "Home & Garden": [
        "EPA approved safe for environment",
        "Chemical free and 100% organic",
        "Kills 100% of pests and insects",
        "Safe around children and pets guaranteed", 
        "Biodegradable and eco-friendly certified"
      ],
      "Baby & Child Care": [
        "Pediatrician approved and recommended",
        "100% safe for babies and children",
        "Hypoallergenic guaranteed formula",
        "Dermatologist tested and approved",
        "Chemical free and all natural ingredients"
      ]
    };
    
    return problematicBullets[category] || [
      `High quality ${keywords} product`,
      `Professional grade materials`,
      `Trusted by customers worldwide`
    ];
  }

  private generateRealisticDescription(keywords: string, category: string): string {
    const descriptions = {
      "Health & Personal Care": `Our revolutionary ${keywords} is scientifically proven to eliminate 100% of bacteria and viruses. FDA certified and recommended by all doctors worldwide. Prevents coronavirus, flu, and all other diseases. Much stronger than what hospitals use.`,
      "Electronics": `This ${keywords} device features military grade construction and FCC approved technology. Blocks 100% of harmful radiation and provides professional quality performance. Government tested and certified safe.`,
      "Home & Garden": `Our ${keywords} solution is EPA approved and completely chemical free. Eliminates 100% of pests while being safe around children. Organic certified and biodegradable formula.`,
      "Baby & Child Care": `This ${keywords} product is pediatrician approved and 100% safe for babies. Hypoallergenic guaranteed with dermatologist tested formula. Chemical free and all natural ingredients.`
    };
    
    return descriptions[category] || `High quality ${keywords} product with professional features.`;
  }

  private parseSearchResults(html: string, maxResults: number): AmazonProduct[] {
    const products: AmazonProduct[] = [];
    
    // Extract product data using regex patterns (simplified approach)
    // In a production environment, you'd want to use a proper HTML parser
    
    // Extract ASINs
    const asinMatches = html.match(/data-asin="([A-Z0-9]{10})"/g) || [];
    const asins = asinMatches.map(match => match.match(/data-asin="([A-Z0-9]{10})"/)?.[1]).filter(Boolean) as string[];

    // Extract product titles
    const titleMatches = html.match(/<h2[^>]*><a[^>]*><span[^>]*>([^<]+)<\/span>/g) || [];
    const titles = titleMatches.map(match => {
      const titleMatch = match.match(/<span[^>]*>([^<]+)<\/span>/);
      return titleMatch ? titleMatch[1].trim() : '';
    }).filter(Boolean);

    // Extract product URLs
    const urlMatches = html.match(/href="([^"]*\/dp\/[A-Z0-9]{10}[^"]*)"/g) || [];
    const urls = urlMatches.map(match => {
      const urlMatch = match.match(/href="([^"]*)"/);
      if (urlMatch) {
        const url = urlMatch[1];
        return url.startsWith('/') ? `${this.baseUrl}${url}` : url;
      }
      return '';
    }).filter(Boolean);

    // Extract prices
    const priceMatches = html.match(/\$[\d,]+\.?\d*/g) || [];
    const prices = priceMatches.slice(0, Math.min(asins.length, maxResults));

    // Create product objects
    const limit = Math.min(asins.length, titles.length, urls.length, maxResults);
    
    for (let i = 0; i < limit; i++) {
      if (asins[i] && titles[i] && urls[i]) {
        products.push({
          asin: asins[i],
          title: this.cleanText(titles[i]),
          url: urls[i],
          bullets: [], // Will be filled by detailed product fetch
          description: '', // Will be filled by detailed product fetch
          category: 'General', // Will be determined during analysis
          price: prices[i] || undefined,
          rating: undefined,
          reviewCount: undefined,
          imageUrl: undefined
        });
      }
    }

    return products;
  }

  async getProductDetails(asin: string): Promise<Partial<AmazonProduct>> {
    try {
      const productUrl = `${this.baseUrl}/dp/${asin}`;
      
      const response = await fetch(productUrl, {
        headers: {
          'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36',
          'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8',
          'Accept-Language': 'en-US,en;q=0.5',
        }
      });

      if (!response.ok) {
        throw new Error(`Product fetch failed: ${response.status}`);
      }

      const html = await response.text();
      return this.parseProductDetails(html);
    } catch (error) {
      console.error(`Error fetching product details for ${asin}:`, error);
      return {
        bullets: [],
        description: 'Product details unavailable'
      };
    }
  }

  private parseProductDetails(html: string): Partial<AmazonProduct> {
    const details: Partial<AmazonProduct> = {
      bullets: [],
      description: ''
    };

    // Extract bullet points
    const bulletMatches = html.match(/<span class="a-list-item">([^<]+)</g) || [];
    details.bullets = bulletMatches
      .map(match => {
        const bulletMatch = match.match(/<span class="a-list-item">([^<]+)/);
        return bulletMatch ? this.cleanText(bulletMatch[1]) : '';
      })
      .filter(bullet => bullet.length > 10 && !bullet.includes('Make sure') && !bullet.includes('ASIN'))
      .slice(0, 5); // Limit to 5 bullets

    // Extract description from feature div
    const descMatches = html.match(/<div[^>]*feature[^>]*>([^<]+)</g) || [];
    if (descMatches.length > 0 && descMatches[0]) {
      details.description = this.cleanText(descMatches[0].replace(/<[^>]*>/g, ''));
    } else {
      // Fallback to meta description
      const metaMatch = html.match(/<meta name="description" content="([^"]+)"/);
      if (metaMatch) {
        details.description = this.cleanText(metaMatch[1]);
      }
    }

    return details;
  }

  private cleanText(text: string): string {
    return text
      .replace(/&amp;/g, '&')
      .replace(/&lt;/g, '<')
      .replace(/&gt;/g, '>')
      .replace(/&quot;/g, '"')
      .replace(/&#x27;/g, "'")
      .replace(/\s+/g, ' ')
      .trim();
  }
}

export const amazonScraper = new AmazonScraper();