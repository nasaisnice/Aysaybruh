import type { 
  User, 
  InsertUser, 
  Listing, 
  InsertListing, 
  Audit, 
  InsertAudit, 
  Pdf, 
  InsertPdf, 
  Outreach, 
  InsertOutreach, 
  Event, 
  InsertEvent,
  Settings,
  LeadFilter,
  DashboardMetrics
} from "@shared/schema";
import { randomUUID } from "crypto";

export interface IStorage {
  // User management
  createUser(user: InsertUser): Promise<string>;
  getUserByUsername(username: string): Promise<User | null>;
  getUserById(id: string): Promise<User | null>;

  // Listing management
  createListing(listing: InsertListing): Promise<string>;
  getListingById(id: string): Promise<Listing | null>;
  getListings(filter: LeadFilter): Promise<{ listings: Listing[]; total: number }>;
  updateListingState(id: string, state: Listing['state'], severity?: Listing['severity']): Promise<void>;
  deleteListing(id: string): Promise<void>;

  // Audit management
  createAudit(audit: InsertAudit): Promise<string>;
  getAuditById(id: string): Promise<Audit | null>;
  getAuditByListingId(listingId: string): Promise<Audit | null>;
  getAuditsByListingId(listingId: string): Promise<Audit[]>;

  // PDF management
  createPdf(pdf: InsertPdf): Promise<string>;
  getPdfById(id: string): Promise<Pdf | null>;
  getPdfByListingId(listingId: string): Promise<Pdf | null>;
  deletePdf(id: string): Promise<void>;

  // Outreach management
  createOutreach(outreach: InsertOutreach): Promise<string>;
  getOutreachById(id: string): Promise<Outreach | null>;
  getOutreachByListingId(listingId: string): Promise<Outreach[]>;
  updateOutreachStatus(id: string, status: Outreach['status'], error?: string): Promise<void>;

  // Event tracking
  createEvent(event: InsertEvent): Promise<string>;
  getEventsByListingId(listingId: string): Promise<Event[]>;

  // Settings management
  getSettings(): Promise<Settings>;
  updateSettings(settings: Partial<Settings>): Promise<void>;

  // Dashboard metrics
  getDashboardMetrics(): Promise<DashboardMetrics>;
}

export class MemStorage implements IStorage {
  private users: Map<string, User> = new Map();
  private listings: Map<string, Listing> = new Map();
  private audits: Map<string, Audit> = new Map();
  private pdfs: Map<string, Pdf> = new Map();
  private outreach: Map<string, Outreach> = new Map();
  private events: Map<string, Event> = new Map();
  private settings: Settings = {
    branding: {
      logo_url: undefined,
      primary_color: "#2563eb",
      company_name: "Compliance Pro",
    },
    pricing: {
      audit_fix_price: 299,
      monthly_retainer: 99,
    },
    outreach: {
      subject: "Quick fix to reduce {product_name} compliance risk (found {top_severity})",
      body: "We found compliance issues with your listing that could impact your Amazon performance...",
      cta_primary: "Get Fixed-Price Audit ($299)",
      cta_secondary: "Schedule Free Consultation",
      booking_link: "https://calendly.com/compliance-pro",
      checkout_link: "https://checkout.compliance-pro.com",
    },
    risk_dictionary: {
      categories: {
        "Household Cleaners": {
          phrases: {
            critical: ["kills covid", "fda approved", "medical grade"],
            high: ["kills 99.9%", "eliminates all germs", "hospital grade"],
            moderate: ["antibacterial", "disinfectant", "sanitizer"],
            low: ["cleans", "freshens", "removes odors"],
          },
        },
        "Dietary Supplements": {
          phrases: {
            critical: ["cures cancer", "treats disease", "prevents illness"],
            high: ["boosts immunity", "detoxifies", "burns fat"],
            moderate: ["supports health", "natural ingredients", "clinically tested"],
            low: ["dietary supplement", "nutritional support", "wellness"],
          },
        },
      },
    },
  };

  // User management
  async createUser(user: InsertUser): Promise<string> {
    const id = randomUUID();
    const newUser: User = { 
      ...user, 
      id, 
      createdAt: new Date(), 
      updatedAt: new Date() 
    };
    this.users.set(id, newUser);
    return id;
  }

  async getUserByUsername(username: string): Promise<User | null> {
    return Array.from(this.users.values()).find(
      (user) => user.username === username,
    ) || null;
  }

  async getUserById(id: string): Promise<User | null> {
    return this.users.get(id) || null;
  }

  // Listing management
  async createListing(listing: InsertListing): Promise<string> {
    const id = randomUUID();
    const newListing: Listing = {
      ...listing,
      id,
      createdAt: new Date(),
      updatedAt: new Date(),
    };
    this.listings.set(id, newListing);
    return id;
  }

  async getListingById(id: string): Promise<Listing | null> {
    return this.listings.get(id) || null;
  }

  async getListings(filter: LeadFilter): Promise<{ listings: Listing[]; total: number }> {
    let filtered = Array.from(this.listings.values());

    if (filter.severity) {
      filtered = filtered.filter(l => l.severity === filter.severity);
    }
    if (filter.category) {
      filtered = filtered.filter(l => l.category === filter.category);
    }
    if (filter.state) {
      filtered = filtered.filter(l => l.state === filter.state);
    }

    // Sort by creation date (newest first)
    filtered.sort((a, b) => new Date(b.createdAt!).getTime() - new Date(a.createdAt!).getTime());

    const total = filtered.length;
    const start = (filter.page - 1) * filter.limit;
    const listings = filtered.slice(start, start + filter.limit);

    return { listings, total };
  }

  async updateListingState(id: string, state: Listing['state'], severity?: Listing['severity']): Promise<void> {
    const listing = this.listings.get(id);
    if (listing) {
      listing.state = state;
      listing.updatedAt = new Date();
      if (severity !== undefined) {
        listing.severity = severity;
      }
      this.listings.set(id, listing);
    }
  }

  async deleteListing(id: string): Promise<void> {
    this.listings.delete(id);
  }

  // Audit management
  async createAudit(audit: InsertAudit): Promise<string> {
    const id = randomUUID();
    const newAudit: Audit = {
      ...audit,
      id,
      createdAt: new Date(),
    };
    this.audits.set(id, newAudit);
    return id;
  }

  async getAuditById(id: string): Promise<Audit | null> {
    return this.audits.get(id) || null;
  }

  async getAuditByListingId(listingId: string): Promise<Audit | null> {
    return Array.from(this.audits.values()).find(a => a.listingId === listingId) || null;
  }

  async getAuditsByListingId(listingId: string): Promise<Audit[]> {
    return Array.from(this.audits.values()).filter(a => a.listingId === listingId);
  }

  // PDF management
  async createPdf(pdf: InsertPdf): Promise<string> {
    const id = randomUUID();
    const newPdf: Pdf = {
      ...pdf,
      id,
      createdAt: new Date(),
    };
    this.pdfs.set(id, newPdf);
    return id;
  }

  async getPdfById(id: string): Promise<Pdf | null> {
    return this.pdfs.get(id) || null;
  }

  async getPdfByListingId(listingId: string): Promise<Pdf | null> {
    return Array.from(this.pdfs.values()).find(p => p.listingId === listingId) || null;
  }

  async deletePdf(id: string): Promise<void> {
    this.pdfs.delete(id);
  }

  // Outreach management
  async createOutreach(outreach: InsertOutreach): Promise<string> {
    const id = randomUUID();
    const newOutreach: Outreach = {
      ...outreach,
      id,
      createdAt: new Date(),
      updatedAt: new Date(),
    };
    this.outreach.set(id, newOutreach);
    return id;
  }

  async getOutreachById(id: string): Promise<Outreach | null> {
    return this.outreach.get(id) || null;
  }

  async getOutreachByListingId(listingId: string): Promise<Outreach[]> {
    return Array.from(this.outreach.values()).filter(o => o.listingId === listingId);
  }

  async updateOutreachStatus(id: string, status: Outreach['status'], error?: string): Promise<void> {
    const outreach = this.outreach.get(id);
    if (outreach) {
      outreach.status = status;
      outreach.updatedAt = new Date();
      if (error) {
        outreach.lastError = error;
      }
      this.outreach.set(id, outreach);
    }
  }

  // Event tracking
  async createEvent(event: InsertEvent): Promise<string> {
    const id = randomUUID();
    const newEvent: Event = {
      ...event,
      id,
      createdAt: new Date(),
    };
    this.events.set(id, newEvent);
    return id;
  }

  async getEventsByListingId(listingId: string): Promise<Event[]> {
    return Array.from(this.events.values())
      .filter(e => e.listingId === listingId)
      .sort((a, b) => new Date(b.createdAt!).getTime() - new Date(a.createdAt!).getTime());
  }

  // Settings management
  async getSettings(): Promise<Settings> {
    return this.settings;
  }

  async updateSettings(newSettings: Partial<Settings>): Promise<void> {
    this.settings = { ...this.settings, ...newSettings };
  }

  // Dashboard metrics
  async getDashboardMetrics(): Promise<DashboardMetrics> {
    const listings = Array.from(this.listings.values());
    
    const leads = {
      total: listings.length,
      new: listings.filter(l => l.state === 'new').length,
      audited: listings.filter(l => ['audited', 'pdf_ready', 'outreach_queued', 'contacted', 'replied', 'won', 'lost'].includes(l.state)).length,
      contacted: listings.filter(l => ['contacted', 'replied', 'won', 'lost'].includes(l.state)).length,
      replied: listings.filter(l => ['replied', 'won', 'lost'].includes(l.state)).length,
      won: listings.filter(l => l.state === 'won').length,
    };

    const severity = {
      critical: listings.filter(l => l.severity === 'critical').length,
      high: listings.filter(l => l.severity === 'high').length,
      moderate: listings.filter(l => l.severity === 'moderate').length,
      low: listings.filter(l => l.severity === 'low').length,
    };

    const conversion = {
      contact_rate: leads.total > 0 ? leads.contacted / leads.total : 0,
      reply_rate: leads.contacted > 0 ? leads.replied / leads.contacted : 0,
      win_rate: leads.replied > 0 ? leads.won / leads.replied : 0,
    };

    return { leads, severity, conversion };
  }
}

export const storage = new MemStorage();
