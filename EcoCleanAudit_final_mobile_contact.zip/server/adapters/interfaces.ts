import type { Listing, InsertListing, Finding } from "@shared/schema";

// Listing Source Adapter Interface
export interface ListingSourceAdapter {
  searchListings(keywords: string, options?: {
    category?: string;
    maxResults?: number;
    marketplace?: string;
  }): Promise<ListingData[]>;
  
  getListingDetails(url: string): Promise<ListingData>;
}

export interface ListingData {
  url: string;
  asin?: string;
  title: string;
  bullets: string[];
  description?: string;
  images: string[];
  category?: string;
  sellerName?: string;
  sellerStoreUrl?: string;
  sellerContactUrl?: string;
  price?: string;
  rating?: number;
  reviewCount?: number;
}

// Parser Adapter Interface
export interface ParserAdapter {
  parseListingHtml(html: string, url: string): Promise<ListingData>;
  extractSellerContacts(html: string): Promise<{
    email?: string;
    contactUrl?: string;
    storeUrl?: string;
  }>;
}

// Signal Engine Adapter Interface
export interface SignalEngineAdapter {
  analyzeRiskSignals(listing: ListingData): Promise<{
    signals: Record<string, any>;
    severity: "low" | "moderate" | "high" | "critical" | null;
    score: number;
  }>;
}

// Audit Engine Adapter Interface
export interface AuditEngineAdapter {
  auditListing(listing: Pick<Listing, 'title' | 'bullets' | 'description' | 'category'>): Promise<{
    findings: Finding[];
    summary: Record<string, any>;
    modelOrEngine: string;
  }>;
}

// PDF Renderer Adapter Interface
export interface PdfRendererAdapter {
  generateComplianceReport(data: {
    listing: Listing;
    findings: Finding[];
    branding: {
      logo_url?: string;
      primary_color: string;
      company_name: string;
    };
    pricing: {
      audit_fix_price: number;
      monthly_retainer: number;
    };
  }): Promise<{
    buffer: Buffer;
    filename: string;
  }>;
}

// Storage Adapter Interface
export interface StorageAdapter {
  uploadFile(buffer: Buffer, key: string, contentType: string): Promise<{
    url: string;
    key: string;
  }>;
  
  deleteFile(key: string): Promise<void>;
  
  getSignedUrl(key: string, expiresIn?: number): Promise<string>;
}

// Email Adapter Interface
export interface EmailAdapter {
  sendEmail(params: {
    to: string;
    subject: string;
    html: string;
    text?: string;
    replyTo?: string;
    trackingId?: string;
  }): Promise<{
    messageId: string;
    status: "sent" | "failed";
    error?: string;
  }>;
  
  handleWebhook(payload: any): Promise<{
    messageId: string;
    event: "delivered" | "bounced" | "replied" | "opened";
    data?: Record<string, any>;
  }>;
}

// Metrics Adapter Interface
export interface MetricsAdapter {
  logEvent(event: {
    type: string;
    listingId?: string;
    payload: Record<string, any>;
    timestamp?: Date;
  }): Promise<void>;
  
  incrementCounter(metric: string, tags?: Record<string, string>): Promise<void>;
  
  recordDuration(metric: string, duration: number, tags?: Record<string, string>): Promise<void>;
  
  getDashboardMetrics(): Promise<{
    leads: {
      total: number;
      new: number;
      audited: number;
      contacted: number;
      replied: number;
      won: number;
    };
    severity: {
      critical: number;
      high: number;
      moderate: number;
      low: number;
    };
    conversion: {
      contact_rate: number;
      reply_rate: number;
      win_rate: number;
    };
  }>;
}

// Queue Adapter Interface
export interface QueueAdapter {
  addJob<T = any>(queue: string, job: string, data: T, options?: {
    delay?: number;
    attempts?: number;
    backoff?: {
      type: 'exponential' | 'fixed';
      delay: number;
    };
    priority?: number;
  }): Promise<void>;
  
  process<T = any>(queue: string, concurrency: number, processor: (job: {
    id: string;
    name: string;
    data: T;
    attemptsMade: number;
  }) => Promise<void>): void;
  
  getQueueStats(queue: string): Promise<{
    waiting: number;
    active: number;
    completed: number;
    failed: number;
    delayed: number;
  }>;
}