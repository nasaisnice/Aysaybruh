import type { PdfRendererAdapter } from "./interfaces";
import type { Listing, Finding } from "@shared/schema";

export class SimplePdfRenderer implements PdfRendererAdapter {
  async generateComplianceReport(data: {
    listing: Listing;
    findings: Finding[];
    branding: {
      logo_url?: string;
      primary_color: string;
      company_name: string;
    };
    pricing: {
      audit_fix_price: number;
      monthly_retainer: number;
    };
  }): Promise<{ buffer: Buffer; filename: string }> {
    const { listing, findings, branding, pricing } = data;
    
    // Generate HTML content for the PDF
    const html = this.generateReportHtml(listing, findings, branding, pricing);
    
    // For now, convert HTML to a simple text-based PDF representation
    // In production, you'd use a library like puppeteer or pdf-lib
    const textContent = this.htmlToText(html);
    const buffer = Buffer.from(textContent, 'utf-8');
    
    const filename = `compliance-report-${listing.id}-${Date.now()}.pdf`;
    
    return { buffer, filename };
  }

  private generateReportHtml(
    listing: Listing, 
    findings: Finding[], 
    branding: any, 
    pricing: any
  ): string {
    const criticalFindings = findings.filter(f => f.severity === 'critical');
    const highFindings = findings.filter(f => f.severity === 'high');
    const moderateFindings = findings.filter(f => f.severity === 'moderate');
    const lowFindings = findings.filter(f => f.severity === 'low');

    return `
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Compliance Report - ${listing.title}</title>
    <style>
        body { 
            font-family: Arial, sans-serif; 
            line-height: 1.6; 
            color: #333; 
            max-width: 800px; 
            margin: 0 auto; 
            padding: 20px; 
        }
        .header { 
            background: ${branding.primary_color}; 
            color: white; 
            padding: 30px; 
            text-align: center; 
            margin: -20px -20px 30px -20px; 
        }
        .logo { font-size: 24px; font-weight: bold; }
        .product-title { font-size: 18px; margin: 20px 0; }
        .severity-critical { color: #dc2626; font-weight: bold; }
        .severity-high { color: #ea580c; font-weight: bold; }
        .severity-moderate { color: #d97706; font-weight: bold; }
        .severity-low { color: #65a30d; font-weight: bold; }
        .finding { 
            border: 1px solid #e5e7eb; 
            border-radius: 8px; 
            padding: 15px; 
            margin: 15px 0; 
            background: #f9fafb; 
        }
        .claim { font-style: italic; background: #fef3c7; padding: 5px; border-radius: 4px; }
        .recommendation { background: #ecfdf5; padding: 10px; border-radius: 4px; margin-top: 10px; }
        .cta-section { 
            background: #f3f4f6; 
            border: 2px solid ${branding.primary_color}; 
            border-radius: 8px; 
            padding: 20px; 
            margin: 30px 0; 
            text-align: center; 
        }
        .price { font-size: 24px; font-weight: bold; color: ${branding.primary_color}; }
        .summary-table { width: 100%; border-collapse: collapse; margin: 20px 0; }
        .summary-table th, .summary-table td { 
            border: 1px solid #d1d5db; 
            padding: 10px; 
            text-align: left; 
        }
        .summary-table th { background: #f3f4f6; }
        .footer { 
            border-top: 1px solid #e5e7eb; 
            padding-top: 20px; 
            margin-top: 40px; 
            font-size: 12px; 
            color: #6b7280; 
        }
    </style>
</head>
<body>
    <div class="header">
        <div class="logo">${branding.company_name}</div>
        <div>Marketplace Compliance Report</div>
        <div class="product-title">${listing.title}</div>
    </div>

    <h2>Executive Summary</h2>
    <table class="summary-table">
        <tr>
            <th>Metric</th>
            <th>Count</th>
        </tr>
        <tr>
            <td>Critical Issues</td>
            <td class="severity-critical">${criticalFindings.length}</td>
        </tr>
        <tr>
            <td>High Risk Issues</td>
            <td class="severity-high">${highFindings.length}</td>
        </tr>
        <tr>
            <td>Moderate Issues</td>
            <td class="severity-moderate">${moderateFindings.length}</td>
        </tr>
        <tr>
            <td>Low Priority Issues</td>
            <td class="severity-low">${lowFindings.length}</td>
        </tr>
        <tr>
            <td><strong>Total Issues</strong></td>
            <td><strong>${findings.length}</strong></td>
        </tr>
    </table>

    <h2>Detailed Findings</h2>
    
    ${findings.length === 0 ? '<p>No compliance issues detected. Great job!</p>' : ''}
    
    ${criticalFindings.map(finding => `
        <div class="finding">
            <h3 class="severity-critical">🚨 CRITICAL: ${finding.rule_violated}</h3>
            <p><strong>Problematic Text:</strong> <span class="claim">"${finding.claim_text}"</span></p>
            <p><strong>Issue:</strong> ${finding.why_it_fails}</p>
            <div class="recommendation">
                <strong>Recommended Fix:</strong> ${finding.corrective_copy}
                ${finding.suggested_label_change ? `<br><strong>Suggested Label:</strong> "${finding.suggested_label_change}"` : ''}
                ${finding.required_evidence_or_doc ? `<br><strong>Required Documentation:</strong> ${finding.required_evidence_or_doc}` : ''}
            </div>
        </div>
    `).join('')}

    ${highFindings.map(finding => `
        <div class="finding">
            <h3 class="severity-high">⚠️ HIGH RISK: ${finding.rule_violated}</h3>
            <p><strong>Problematic Text:</strong> <span class="claim">"${finding.claim_text}"</span></p>
            <p><strong>Issue:</strong> ${finding.why_it_fails}</p>
            <div class="recommendation">
                <strong>Recommended Fix:</strong> ${finding.corrective_copy}
                ${finding.suggested_label_change ? `<br><strong>Suggested Label:</strong> "${finding.suggested_label_change}"` : ''}
                ${finding.required_evidence_or_doc ? `<br><strong>Required Documentation:</strong> ${finding.required_evidence_or_doc}` : ''}
            </div>
        </div>
    `).join('')}

    ${moderateFindings.map(finding => `
        <div class="finding">
            <h3 class="severity-moderate">🔶 MODERATE: ${finding.rule_violated}</h3>
            <p><strong>Problematic Text:</strong> <span class="claim">"${finding.claim_text}"</span></p>
            <p><strong>Issue:</strong> ${finding.why_it_fails}</p>
            <div class="recommendation">
                <strong>Recommended Fix:</strong> ${finding.corrective_copy}
                ${finding.suggested_label_change ? `<br><strong>Suggested Label:</strong> "${finding.suggested_label_change}"` : ''}
                ${finding.required_evidence_or_doc ? `<br><strong>Required Documentation:</strong> ${finding.required_evidence_or_doc}` : ''}
            </div>
        </div>
    `).join('')}

    ${lowFindings.map(finding => `
        <div class="finding">
            <h3 class="severity-low">💡 LOW PRIORITY: ${finding.rule_violated}</h3>
            <p><strong>Problematic Text:</strong> <span class="claim">"${finding.claim_text}"</span></p>
            <p><strong>Issue:</strong> ${finding.why_it_fails}</p>
            <div class="recommendation">
                <strong>Recommended Fix:</strong> ${finding.corrective_copy}
                ${finding.suggested_label_change ? `<br><strong>Suggested Label:</strong> "${finding.suggested_label_change}"` : ''}
                ${finding.required_evidence_or_doc ? `<br><strong>Required Documentation:</strong> ${finding.required_evidence_or_doc}` : ''}
            </div>
        </div>
    `).join('')}

    <div class="cta-section">
        <h2>Get Your Listing Fixed</h2>
        <p>Don't let compliance issues hurt your Amazon performance. We can help you fix these issues quickly and professionally.</p>
        
        <div style="display: flex; justify-content: space-around; margin: 20px 0;">
            <div>
                <h3>Complete Fix</h3>
                <div class="price">$${pricing.audit_fix_price}</div>
                <p>One-time complete fix of all issues</p>
                <p><strong>Get Started Now</strong></p>
            </div>
            <div>
                <h3>Ongoing Monitoring</h3>
                <div class="price">$${pricing.monthly_retainer}/mo</div>
                <p>Monthly compliance monitoring</p>
                <p><strong>Schedule Consultation</strong></p>
            </div>
        </div>
    </div>

    <div class="footer">
        <p><strong>Disclaimer:</strong> This report is for informational purposes only and does not constitute legal advice. 
        Always consult with qualified legal professionals for compliance matters.</p>
        <p>Generated by ${branding.company_name} on ${new Date().toLocaleDateString()}</p>
    </div>
</body>
</html>`;
  }

  private htmlToText(html: string): string {
    // Simple HTML to text conversion for demo purposes
    // In production, use a proper HTML-to-PDF library like puppeteer
    return html
      .replace(/<[^>]*>/g, '') // Remove HTML tags
      .replace(/&nbsp;/g, ' ')
      .replace(/&amp;/g, '&')
      .replace(/&lt;/g, '<')
      .replace(/&gt;/g, '>')
      .replace(/\s+/g, ' ') // Normalize whitespace
      .trim();
  }
}