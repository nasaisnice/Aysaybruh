# Marketplace Compliance Platform

## Overview

This is a production-ready, end-to-end marketplace compliance platform that identifies risky listings, audits them for violations, generates branded compliance reports, and drives paid conversions through automated outreach. The system uses an adapter-based architecture for maximum modularity and provider flexibility.

## Recent Changes

**December 12, 2024:** Major architectural upgrade from simple auditor to full lead generation platform:
- Implemented modular adapter pattern for all external services
- Added automated scraping and lead identification pipeline
- Built PDF report generation with branded templates
- Created outreach automation with email campaigns
- Added comprehensive admin UI for lead management
- Integrated state machine for lead lifecycle tracking

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Frontend Architecture
- **Framework**: React with TypeScript using Vite as the build tool
- **UI Components**: Shadcn/ui component library with Radix UI primitives
- **Styling**: Tailwind CSS with custom design tokens and CSS variables
- **State Management**: React Hook Form for form handling, TanStack Query for server state
- **Routing**: Wouter for lightweight client-side routing
- **Design Pattern**: Component-based architecture with reusable UI components

### Backend Architecture
- **Runtime**: Node.js with Express.js framework
- **Language**: TypeScript with ES modules
- **API Design**: RESTful endpoints with JSON request/response format
- **Error Handling**: Centralized error middleware with structured error responses
- **Request Processing**: JSON and URL-encoded body parsing with request logging

### Data Storage Solutions
- **Database**: PostgreSQL with Drizzle ORM for type-safe database operations
- **Connection**: Neon Database serverless PostgreSQL
- **Schema Management**: Drizzle Kit for migrations and schema management
- **In-Memory Storage**: Temporary storage implementation for user data during development

### Authentication and Authorization
- **Current State**: Basic user schema defined but authentication not fully implemented
- **Planned Structure**: Username/password based authentication with session management
- **Session Storage**: PostgreSQL session store configured for production use

### API Structure
- **Compliance Audit Endpoint**: POST `/api/audit` - Accepts listing data and returns violation analysis
- **Input Validation**: Zod schemas for request validation and type safety
- **Response Format**: Structured JSON with violations array and summary statistics
- **Error Responses**: HTTP status codes with descriptive error messages

## External Dependencies

### Core Services
- **OpenAI API**: GPT-4o model for AI-powered compliance analysis and violation detection
- **Neon Database**: Serverless PostgreSQL hosting for production data storage

### Development Tools
- **Replit Integration**: Development environment plugins for debugging and cartographer
- **Vite Plugins**: Runtime error overlay and development tooling

### UI Libraries
- **Radix UI**: Comprehensive set of accessible UI primitives (accordion, dialog, dropdown, etc.)
- **Shadcn/ui**: Pre-built component library built on top of Radix UI
- **Lucide React**: Icon library for consistent iconography
- **Class Variance Authority**: Utility for creating component variants

### Data Management
- **TanStack Query**: Server state management, caching, and synchronization
- **React Hook Form**: Form state management with validation
- **Hookform Resolvers**: Integration between React Hook Form and Zod validation

### Styling and Design
- **Tailwind CSS**: Utility-first CSS framework with custom configuration
- **PostCSS**: CSS processing with autoprefixer
- **Custom Fonts**: Google Fonts integration (Inter, DM Sans, Fira Code, Geist Mono)

### Utilities
- **Date-fns**: Date manipulation and formatting
- **clsx**: Conditional CSS class names
- **nanoid**: Unique ID generation
- **cmdk**: Command palette component