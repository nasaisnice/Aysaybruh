Vercel deploy (mobile-optimized)
1. Push this repo to GitHub.
2. On your iPad/phone, open vercel.com -> Import Project -> select this repo.
3. Vercel will run `npm run build` and deploy. If you want a client-only static deploy, set the client build to `cd client && npm run build` and set the output directory to `client/dist`.
4. After deploy, open the provided URL on your phone/iPad.
Optimizations added:
- Lazy-loading of heavy pages (React.lazy + Suspense)
- Mobile-first Dashboard page (client/src/pages/mobile-dashboard.tsx)
- Vercel config for server + static client routing
