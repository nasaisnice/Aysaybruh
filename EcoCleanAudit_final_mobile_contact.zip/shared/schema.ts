import { sql } from "drizzle-orm";
import { pgTable, text, varchar, jsonb, timestamp, integer, boolean } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

// Core entity tables
export const users = pgTable("users", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

// Listings with full lead tracking
export const listings = pgTable("listings", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  asin: text("asin"),
  url: text("url").notNull(),
  category: text("category"),
  title: text("title").notNull(),
  bullets: jsonb("bullets").$type<string[]>().default([]),
  description: text("description"),
  images: jsonb("images").$type<string[]>().default([]),
  sellerName: text("seller_name"),
  sellerStoreUrl: text("seller_store_url"),
  sellerContactUrl: text("seller_contact_url"),
  signals: jsonb("signals").$type<Record<string, any>>().default({}),
  severity: text("severity", { enum: ["low", "moderate", "high", "critical"] }),
  state: text("state", { 
    enum: ["new", "scraped", "audited", "pdf_ready", "outreach_queued", "contacted", "replied", "won", "lost"] 
  }).default("new"),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

// Audit results
export const audits = pgTable("audits", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  listingId: varchar("listing_id").references(() => listings.id).notNull(),
  modelOrEngine: text("model_or_engine").notNull(),
  findings: jsonb("findings").$type<Finding[]>().default([]),
  summary: jsonb("summary").$type<Record<string, any>>(),
  createdAt: timestamp("created_at").defaultNow(),
});

// PDF reports
export const pdfs = pgTable("pdfs", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  listingId: varchar("listing_id").references(() => listings.id).notNull(),
  url: text("url").notNull(),
  bytes: integer("bytes"),
  createdAt: timestamp("created_at").defaultNow(),
});

// Outreach campaigns
export const outreach = pgTable("outreach", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  listingId: varchar("listing_id").references(() => listings.id).notNull(),
  channel: text("channel", { enum: ["email", "form"] }).notNull(),
  toAddress: text("to_address"),
  subject: text("subject"),
  body: text("body"),
  status: text("status", { 
    enum: ["queued", "sent", "bounced", "delivered", "replied"] 
  }).default("queued"),
  lastError: text("last_error"),
  providerMsgId: text("provider_msg_id"),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

// Event tracking
export const events = pgTable("events", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  listingId: varchar("listing_id").references(() => listings.id),
  type: text("type").notNull(),
  payload: jsonb("payload").$type<Record<string, any>>().default({}),
  createdAt: timestamp("created_at").defaultNow(),
});

// Insert schemas
export const insertUserSchema = createInsertSchema(users).pick({
  username: true,
  password: true,
});

export const insertListingSchema = createInsertSchema(listings).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export const insertAuditSchema = createInsertSchema(audits).omit({
  id: true,
  createdAt: true,
});

export const insertPdfSchema = createInsertSchema(pdfs).omit({
  id: true,
  createdAt: true,
});

export const insertOutreachSchema = createInsertSchema(outreach).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export const insertEventSchema = createInsertSchema(events).omit({
  id: true,
  createdAt: true,
});

// Types
export type User = typeof users.$inferSelect;
export type InsertUser = z.infer<typeof insertUserSchema>;
export type Listing = typeof listings.$inferSelect;
export type InsertListing = z.infer<typeof insertListingSchema>;
export type Audit = typeof audits.$inferSelect;
export type InsertAudit = z.infer<typeof insertAuditSchema>;
export type Pdf = typeof pdfs.$inferSelect;
export type InsertPdf = z.infer<typeof insertPdfSchema>;
export type Outreach = typeof outreach.$inferSelect;
export type InsertOutreach = z.infer<typeof insertOutreachSchema>;
export type Event = typeof events.$inferSelect;
export type InsertEvent = z.infer<typeof insertEventSchema>;

// Listing schema
export const listingSchema = z.object({
  category: z.string(),
  title: z.string(),
  bullets: z.array(z.string()),
  description: z.string(),
});

export type Listing = z.infer<typeof listingSchema>;

// Violation schema
export const violationSchema = z.object({
  claim_text: z.string(),
  rule_violated: z.string(),
  why_it_fails: z.string(),
  severity: z.enum(["low", "moderate", "high", "critical"]),
  corrective_copy: z.string(),
  required_evidence_or_doc: z.string(),
  suggested_label_change: z.string().optional(),
});

export type Violation = z.infer<typeof violationSchema>;
export type Finding = Violation; // Alias for enterprise platform

// Analysis result schema
export const analysisResultSchema = z.object({
  violations: z.array(violationSchema),
  summary: z.object({
    total: z.number(),
    critical: z.number(),
    high: z.number(),
    moderate: z.number(),
    low: z.number(),
    compliant: z.boolean(),
  }),
});

export type AnalysisResult = z.infer<typeof analysisResultSchema>;

// Amazon search schemas
export const amazonSearchSchema = z.object({
  keywords: z.string().min(1, "Search keywords are required"),
  category: z.string().optional(),
  maxResults: z.number().min(1).max(50).default(10),
});

export type AmazonSearch = z.infer<typeof amazonSearchSchema>;

export const amazonProductSchema = z.object({
  asin: z.string(),
  title: z.string(),
  url: z.string(),
  bullets: z.array(z.string()),
  description: z.string(),
  category: z.string(),
  price: z.string().optional(),
  rating: z.number().optional(),
  reviewCount: z.number().optional(),
  imageUrl: z.string().optional(),
});

export type AmazonProduct = z.infer<typeof amazonProductSchema>;

export const scanResultSchema = z.object({
  searchQuery: z.string(),
  totalProducts: z.number(),
  flaggedProducts: z.array(z.object({
    product: amazonProductSchema,
    analysis: analysisResultSchema,
  })),
  summary: z.object({
    totalScanned: z.number(),
    totalFlagged: z.number(),
    criticalViolations: z.number(),
    highViolations: z.number(),
    moderateViolations: z.number(),
    lowViolations: z.number(),
  }),
});

export type ScanResult = z.infer<typeof scanResultSchema>;

// Enterprise platform schemas
export const leadFilterSchema = z.object({
  severity: z.enum(["low", "moderate", "high", "critical"]).optional(),
  category: z.string().optional(),
  state: z.enum(["new", "scraped", "audited", "pdf_ready", "outreach_queued", "contacted", "replied", "won", "lost"]).optional(),
  page: z.number().min(1).default(1),
  limit: z.number().min(1).max(100).default(20),
});

export type LeadFilter = z.infer<typeof leadFilterSchema>;

export const riskDictionarySchema = z.object({
  categories: z.record(z.object({
    phrases: z.record(z.enum(["low", "moderate", "high", "critical"]), z.array(z.string())),
  })),
});

export type RiskDictionary = z.infer<typeof riskDictionarySchema>;

export const outreachTemplateSchema = z.object({
  subject: z.string(),
  body: z.string(),
  cta_primary: z.string(),
  cta_secondary: z.string(),
  booking_link: z.string(),
  checkout_link: z.string(),
});

export type OutreachTemplate = z.infer<typeof outreachTemplateSchema>;

export const settingsSchema = z.object({
  branding: z.object({
    logo_url: z.string().optional(),
    primary_color: z.string().default("#2563eb"),
    company_name: z.string().default("Compliance Pro"),
  }),
  pricing: z.object({
    audit_fix_price: z.number().default(299),
    monthly_retainer: z.number().default(99),
  }),
  outreach: outreachTemplateSchema,
  risk_dictionary: riskDictionarySchema,
});

export type Settings = z.infer<typeof settingsSchema>;

// API response schemas
export const leadDetailSchema = z.object({
  listing: z.object({
    id: z.string(),
    asin: z.string().nullable(),
    url: z.string(),
    title: z.string(),
    bullets: z.array(z.string()),
    description: z.string().nullable(),
    category: z.string().nullable(),
    sellerName: z.string().nullable(),
    severity: z.enum(["low", "moderate", "high", "critical"]).nullable(),
    state: z.enum(["new", "scraped", "audited", "pdf_ready", "outreach_queued", "contacted", "replied", "won", "lost"]),
    createdAt: z.string(),
  }),
  audit: z.object({
    findings: z.array(violationSchema),
    summary: z.record(z.any()),
    createdAt: z.string(),
  }).nullable(),
  pdf: z.object({
    id: z.string(),
    url: z.string(),
    bytes: z.number().nullable(),
    createdAt: z.string(),
  }).nullable(),
  outreach: z.array(z.object({
    id: z.string(),
    channel: z.enum(["email", "form"]),
    toAddress: z.string().nullable(),
    subject: z.string().nullable(),
    status: z.enum(["queued", "sent", "bounced", "delivered", "replied"]),
    createdAt: z.string(),
  })),
  events: z.array(z.object({
    id: z.string(),
    type: z.string(),
    payload: z.record(z.any()),
    createdAt: z.string(),
  })),
});

export type LeadDetail = z.infer<typeof leadDetailSchema>;

export const dashboardMetricsSchema = z.object({
  leads: z.object({
    total: z.number(),
    new: z.number(),
    audited: z.number(),
    contacted: z.number(),
    replied: z.number(),
    won: z.number(),
  }),
  severity: z.object({
    critical: z.number(),
    high: z.number(),
    moderate: z.number(),
    low: z.number(),
  }),
  conversion: z.object({
    contact_rate: z.number(),
    reply_rate: z.number(),
    win_rate: z.number(),
  }),
});

export type DashboardMetrics = z.infer<typeof dashboardMetricsSchema>;
