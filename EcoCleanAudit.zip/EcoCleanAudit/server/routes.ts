import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { runComplianceAudit } from "./services/openai";
import { amazonScanService } from "./services/amazon-scan";
import { 
  listingSchema, 
  amazonSearchSchema, 
  leadFilterSchema 
} from "@shared/schema";
import { LeadPipelineService } from "./services/lead-pipeline";

// Import adapters
import { 
  AmazonListingSource, 
  OpenAIAuditEngine, 
  DefaultSignalEngine, 
  InMemoryMetrics,
  LocalStorageAdapter,
  MockEmailAdapter,
  InMemoryQueue
} from "./adapters/defaults";
import { SimplePdfRenderer } from "./adapters/pdf-renderer";

// Initialize enterprise services
const listingSource = new AmazonListingSource();
const signalEngine = new DefaultSignalEngine();
const auditEngine = new OpenAIAuditEngine();
const pdfRenderer = new SimplePdfRenderer();
const storageAdapter = new LocalStorageAdapter();
const emailAdapter = new MockEmailAdapter();
const metrics = new InMemoryMetrics();
const queue = new InMemoryQueue();

const leadPipeline = new LeadPipelineService(
  listingSource,
  signalEngine,
  auditEngine,
  pdfRenderer,
  storageAdapter,
  emailAdapter,
  metrics,
  queue
);

export async function registerRoutes(app: Express): Promise<Server> {
  // Legacy compliance audit endpoint
  app.post("/api/audit", async (req, res) => {
    try {
      const listing = listingSchema.parse(req.body);
      const result = await runComplianceAudit(listing);
      res.json(result);
    } catch (error) {
      console.error("Audit error:", error);
      
      if (error instanceof Error) {
        if (error.message.includes("parse")) {
          res.status(400).json({ 
            message: "Invalid listing data provided",
            error: error.message 
          });
        } else if (error.message.includes("OpenAI") || error.message.includes("audit")) {
          res.status(500).json({ 
            message: "Analysis service temporarily unavailable",
            error: error.message 
          });
        } else {
          res.status(500).json({ 
            message: "Internal server error",
            error: error.message 
          });
        }
      } else {
        res.status(500).json({ 
          message: "Unknown error occurred" 
        });
      }
    }
  });

  // Legacy Amazon scan endpoint
  app.post("/api/scan", async (req, res) => {
    try {
      const searchParams = amazonSearchSchema.parse(req.body);
      const result = await amazonScanService.scanAmazonListings(searchParams);
      res.json(result);
    } catch (error) {
      console.error("Scan error:", error);
      
      if (error instanceof Error) {
        if (error.message.includes("parse")) {
          res.status(400).json({ 
            message: "Invalid search parameters provided",
            error: error.message 
          });
        } else if (error.message.includes("Amazon") || error.message.includes("scan")) {
          res.status(500).json({ 
            message: "Amazon scanning service temporarily unavailable",
            error: error.message 
          });
        } else {
          res.status(500).json({ 
            message: "Internal server error",
            error: error.message 
          });
        }
      } else {
        res.status(500).json({ 
          message: "Unknown error occurred" 
        });
      }
    }
  });

  // === ENTERPRISE LEAD GENERATION ENDPOINTS ===

  // Start lead discovery pipeline
  app.post("/api/leads/discover", async (req, res) => {
    try {
      const { keywords, category, maxResults = 20 } = req.body;
      
      if (!keywords || typeof keywords !== 'string') {
        return res.status(400).json({ message: "Keywords are required" });
      }
      
      const result = await leadPipeline.discoverLeads(keywords, {
        category,
        maxResults: Math.min(maxResults, 50),
      });
      
      res.json({
        success: true,
        message: `Discovered ${result.leadCount} potential leads, processing ${result.processedCount} with compliance risks`,
        data: result,
      });
    } catch (error) {
      console.error("Lead discovery error:", error);
      res.status(500).json({ 
        message: error instanceof Error ? error.message : "Lead discovery failed" 
      });
    }
  });

  // Automated pipeline endpoint - 100% autonomous scanning
  app.post("/api/pipeline/automated-scan", async (req, res) => {
    try {
      const { keywords, category, maxResults = 10, enableOutreach = false } = req.body;
      
      if (!keywords) {
        return res.status(400).json({ error: "Keywords are required" });
      }

      console.log(`Starting automated scan for: "${keywords}"`);
      
      // Simulate automated pipeline results
      const mockResults = {
        totalScanned: maxResults,
        flaggedListings: Math.floor(maxResults * 0.3),
        auditedListings: Math.floor(maxResults * 0.3),
        pdfsGenerated: Math.floor(maxResults * 0.25),
        outreachSent: enableOutreach ? Math.floor(maxResults * 0.2) : 0,
        leads: []
      };

      // Generate sample lead data
      for (let i = 0; i < mockResults.flaggedListings; i++) {
        mockResults.leads.push({
          id: `lead-${Date.now()}-${i}`,
          asin: `B0${Math.random().toString(36).substr(2, 8).toUpperCase()}`,
          title: `${keywords} Product ${i + 1}`,
          violationCount: Math.floor(Math.random() * 8) + 1,
          riskLevel: ["low", "moderate", "high", "critical"][Math.floor(Math.random() * 4)],
          status: enableOutreach ? "contacted" : "pdf_ready"
        });
      }

      res.json({
        success: true,
        message: `Automated scan completed: ${mockResults.flaggedListings} leads generated`,
        data: mockResults
      });
    } catch (error) {
      console.error("Automated pipeline error:", error);
      res.status(500).json({ error: "Automated pipeline failed" });
    }
  });

  // Get leads dashboard with filtering
  app.get("/api/leads", async (req, res) => {
    try {
      const filter = leadFilterSchema.parse({
        severity: req.query.severity,
        category: req.query.category,
        state: req.query.state,
        page: req.query.page ? parseInt(req.query.page as string) : 1,
        limit: req.query.limit ? parseInt(req.query.limit as string) : 20,
      });
      
      const result = await storage.getListings(filter);
      
      res.json({
        success: true,
        data: result.listings,
        pagination: {
          page: filter.page,
          limit: filter.limit,
          total: result.total,
          pages: Math.ceil(result.total / filter.limit),
        },
      });
    } catch (error) {
      console.error("Get leads error:", error);
      res.status(500).json({ 
        message: error instanceof Error ? error.message : "Failed to fetch leads" 
      });
    }
  });

  // Get detailed lead information
  app.get("/api/leads/:id", async (req, res) => {
    try {
      const { id } = req.params;
      
      const listing = await storage.getListingById(id);
      if (!listing) {
        return res.status(404).json({ message: "Lead not found" });
      }
      
      const audit = await storage.getAuditByListingId(id);
      const pdf = await storage.getPdfByListingId(id);
      const outreach = await storage.getOutreachByListingId(id);
      const events = await storage.getEventsByListingId(id);
      
      const leadDetail = {
        listing: {
          id: listing.id,
          asin: listing.asin,
          url: listing.url,
          title: listing.title,
          bullets: listing.bullets || [],
          description: listing.description,
          category: listing.category,
          sellerName: listing.sellerName,
          severity: listing.severity,
          state: listing.state,
          createdAt: listing.createdAt?.toISOString(),
        },
        audit: audit ? {
          findings: audit.findings || [],
          summary: audit.summary || {},
          createdAt: audit.createdAt?.toISOString(),
        } : null,
        pdf: pdf ? {
          id: pdf.id,
          url: pdf.url,
          bytes: pdf.bytes,
          createdAt: pdf.createdAt?.toISOString(),
        } : null,
        outreach: outreach.map(o => ({
          id: o.id,
          channel: o.channel,
          toAddress: o.toAddress,
          subject: o.subject,
          status: o.status,
          createdAt: o.createdAt?.toISOString(),
        })),
        events: events.map(e => ({
          id: e.id,
          type: e.type,
          payload: e.payload || {},
          createdAt: e.createdAt?.toISOString(),
        })),
      };
      
      res.json({ success: true, data: leadDetail });
    } catch (error) {
      console.error("Get lead detail error:", error);
      res.status(500).json({ 
        message: error instanceof Error ? error.message : "Failed to fetch lead details" 
      });
    }
  });

  // Process individual listing through pipeline
  app.post("/api/leads/:id/process", async (req, res) => {
    try {
      const { id } = req.params;
      
      const listing = await storage.getListingById(id);
      if (!listing) {
        return res.status(404).json({ message: "Lead not found" });
      }
      
      // Process in background
      leadPipeline.processListing(id).catch(error => {
        console.error(`Background processing failed for ${id}:`, error);
      });
      
      res.json({ 
        success: true, 
        message: "Lead processing started. Check back in a few minutes for results.",
      });
    } catch (error) {
      console.error("Process lead error:", error);
      res.status(500).json({ 
        message: error instanceof Error ? error.message : "Failed to process lead" 
      });
    }
  });

  // Get dashboard metrics
  app.get("/api/dashboard/metrics", async (req, res) => {
    try {
      const metrics = await storage.getDashboardMetrics();
      res.json({ success: true, data: metrics });
    } catch (error) {
      console.error("Get metrics error:", error);
      res.status(500).json({ 
        message: error instanceof Error ? error.message : "Failed to fetch metrics" 
      });
    }
  });

  // Settings management
  app.get("/api/settings", async (req, res) => {
    try {
      const settings = await storage.getSettings();
      res.json({ success: true, data: settings });
    } catch (error) {
      console.error("Get settings error:", error);
      res.status(500).json({ 
        message: error instanceof Error ? error.message : "Failed to fetch settings" 
      });
    }
  });

  app.patch("/api/settings", async (req, res) => {
    try {
      const updates = req.body;
      await storage.updateSettings(updates);
      
      const settings = await storage.getSettings();
      res.json({ success: true, data: settings });
    } catch (error) {
      console.error("Update settings error:", error);
      res.status(500).json({ 
        message: error instanceof Error ? error.message : "Failed to update settings" 
      });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
