import { IEmailProvider } from "../adapters/interfaces";
import { DefaultEmailProvider } from "../adapters/defaults";

/**
 * Outreach Automation Service
 * Handles automated email campaigns to sellers
 */
export class OutreachAutomationService {
  constructor(
    private emailProvider: IEmailProvider = new DefaultEmailProvider()
  ) {}

  /**
   * Generate personalized outreach email
   */
  generateOutreachEmail(listing: {
    title: string;
    asin: string;
    category: string;
    violationCount: number;
    topViolation: {
      claim_text: string;
      severity: string;
      rule_violated: string;
    };
  }, pdfUrl: string, sellerName: string): {
    subject: string;
    htmlBody: string;
    textBody: string;
  } {
    const subject = `Amazon Listing Compliance Issue - ${listing.asin} (${listing.violationCount} violations found)`;
    
    const htmlBody = `
      <!DOCTYPE html>
      <html>
      <head>
        <meta charset="utf-8">
        <style>
          body { font-family: Arial, sans-serif; line-height: 1.6; color: #333; }
          .header { background: #232f3e; color: white; padding: 20px; text-align: center; }
          .content { padding: 30px; max-width: 600px; margin: 0 auto; }
          .violation-box { background: #fff3cd; border: 1px solid #ffeaa7; padding: 15px; margin: 20px 0; border-radius: 5px; }
          .critical { background: #f8d7da; border-color: #f5c6cb; }
          .high { background: #fff3cd; border-color: #ffeaa7; }
          .cta-button { background: #ff9900; color: white; padding: 15px 30px; text-decoration: none; border-radius: 5px; display: inline-block; margin: 10px 5px; }
          .cta-button:hover { background: #e88600; }
          .secondary-cta { background: #232f3e; }
          .footer { background: #f8f9fa; padding: 20px; text-align: center; font-size: 12px; color: #666; }
        </style>
      </head>
      <body>
        <div class="header">
          <h1>Amazon Compliance Alert</h1>
          <p>Professional Listing Audit Report</p>
        </div>
        
        <div class="content">
          <h2>Hello ${sellerName},</h2>
          
          <p>We've identified <strong>${listing.violationCount} compliance issues</strong> in your Amazon listing that could result in suppression or account penalties:</p>
          
          <div style="background: #f8f9fa; padding: 15px; border-radius: 5px; margin: 20px 0;">
            <strong>Product:</strong> ${listing.title}<br>
            <strong>ASIN:</strong> ${listing.asin}<br>
            <strong>Category:</strong> ${listing.category}
          </div>
          
          <div class="violation-box ${listing.topViolation.severity}">
            <h3>🚨 Top Priority Issue (${listing.topViolation.severity.toUpperCase()})</h3>
            <p><strong>Problematic Claim:</strong> "${listing.topViolation.claim_text}"</p>
            <p><strong>Rule Violated:</strong> ${listing.topViolation.rule_violated}</p>
          </div>
          
          <h3>📋 Complete Audit Report Available</h3>
          <p>We've prepared a detailed compliance report with:</p>
          <ul>
            <li>✅ All ${listing.violationCount} violations identified</li>
            <li>📝 Specific corrective copy suggestions</li>
            <li>📄 Required evidence documentation</li>
            <li>⚖️ Regulatory compliance guidance</li>
            <li>🎯 Priority ranking for fixes</li>
          </ul>
          
          <div style="text-align: center; margin: 30px 0;">
            <a href="${pdfUrl}" class="cta-button">📥 View Full Report (Free)</a>
          </div>
          
          <h3>🛠️ Professional Fix Service</h3>
          <p>Don't want to handle the fixes yourself? Our compliance experts can:</p>
          <ul>
            <li>Rewrite all problematic content</li>
            <li>Ensure full regulatory compliance</li>
            <li>Provide legal backing documentation</li>
            <li>Guarantee Amazon policy adherence</li>
          </ul>
          
          <div style="background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); color: white; padding: 20px; border-radius: 10px; text-align: center; margin: 20px 0;">
            <h3 style="margin-top: 0; color: white;">Limited Time: $197 Complete Fix Package</h3>
            <p style="font-size: 18px; margin: 10px 0;">Regular Price: $497</p>
            <a href="https://complianceplatform.com/order?asin=${listing.asin}" class="cta-button" style="background: white; color: #667eea; font-weight: bold;">🚀 Fix My Listing Now</a>
          </div>
          
          <h3>🔄 Ongoing Monitoring Service</h3>
          <p>Prevent future issues with our automated monitoring:</p>
          <ul>
            <li>Weekly compliance scans</li>
            <li>Instant violation alerts</li>
            <li>Competitor compliance tracking</li>
            <li>Regulatory update notifications</li>
          </ul>
          
          <div style="text-align: center; margin: 20px 0;">
            <a href="https://complianceplatform.com/monitoring?seller=${encodeURIComponent(sellerName)}" class="cta-button secondary-cta">📊 Start Monitoring ($47/month)</a>
          </div>
          
          <div style="background: #e7f3ff; padding: 15px; border-radius: 5px; margin: 30px 0;">
            <p><strong>⏰ Urgent Action Recommended:</strong> Amazon's algorithm increasingly penalizes non-compliant listings. The sooner you fix these issues, the better your ranking and conversion rates will be.</p>
          </div>
          
          <p>Questions? Simply reply to this email or call us at (555) 123-4567.</p>
          
          <p>Best regards,<br>
          <strong>The Compliance Team</strong><br>
          Professional Amazon Listing Services</p>
        </div>
        
        <div class="footer">
          <p>This automated scan was performed using advanced AI compliance analysis.<br>
          You're receiving this because your listing contains potential policy violations.<br>
          <a href="#">Unsubscribe</a> | <a href="#">Privacy Policy</a></p>
        </div>
      </body>
      </html>
    `;

    const textBody = `
Amazon Compliance Alert - ${listing.violationCount} Violations Found

Hello ${sellerName},

We've identified ${listing.violationCount} compliance issues in your Amazon listing that could result in suppression or account penalties:

Product: ${listing.title}
ASIN: ${listing.asin}
Category: ${listing.category}

TOP PRIORITY ISSUE (${listing.topViolation.severity.toUpperCase()}):
Problematic Claim: "${listing.topViolation.claim_text}"
Rule Violated: ${listing.topViolation.rule_violated}

COMPLETE AUDIT REPORT AVAILABLE:
View your full compliance report: ${pdfUrl}

The report includes:
- All ${listing.violationCount} violations identified
- Specific corrective copy suggestions  
- Required evidence documentation
- Regulatory compliance guidance
- Priority ranking for fixes

PROFESSIONAL FIX SERVICE:
Don't want to handle the fixes yourself? Our compliance experts can rewrite all problematic content, ensure full regulatory compliance, and provide legal backing documentation.

Limited Time: $197 Complete Fix Package (Regular Price: $497)
Order now: https://complianceplatform.com/order?asin=${listing.asin}

ONGOING MONITORING SERVICE:
Prevent future issues with automated monitoring:
- Weekly compliance scans
- Instant violation alerts  
- Competitor compliance tracking
- Regulatory update notifications

Start monitoring: https://complianceplatform.com/monitoring?seller=${encodeURIComponent(sellerName)} ($47/month)

URGENT ACTION RECOMMENDED: Amazon's algorithm increasingly penalizes non-compliant listings. The sooner you fix these issues, the better your ranking and conversion rates will be.

Questions? Simply reply to this email or call us at (555) 123-4567.

Best regards,
The Compliance Team
Professional Amazon Listing Services

---
This automated scan was performed using advanced AI compliance analysis.
You're receiving this because your listing contains potential policy violations.
`;

    return { subject, htmlBody, textBody };
  }

  /**
   * Send outreach email to seller
   */
  async sendOutreach(
    toEmail: string,
    listing: any,
    pdfUrl: string,
    sellerName: string
  ): Promise<{ success: boolean; messageId?: string; error?: string }> {
    try {
      const email = this.generateOutreachEmail(listing, pdfUrl, sellerName);
      
      const result = await this.emailProvider.sendEmail({
        to: toEmail,
        subject: email.subject,
        htmlBody: email.htmlBody,
        textBody: email.textBody,
        from: "compliance@complianceplatform.com",
        replyTo: "support@complianceplatform.com"
      });

      return { success: true, messageId: result.messageId };
    } catch (error) {
      console.error("Outreach email error:", error);
      return { success: false, error: error.message };
    }
  }

  /**
   * Send follow-up email sequence
   */
  async sendFollowUp(
    toEmail: string,
    listing: any,
    daysSinceFirst: number
  ): Promise<{ success: boolean; messageId?: string }> {
    const templates = {
      3: this.generateFollowUp1(listing),
      7: this.generateFollowUp2(listing),
      14: this.generateFinalFollowUp(listing)
    };

    const template = templates[daysSinceFirst];
    if (!template) {
      return { success: false };
    }

    try {
      const result = await this.emailProvider.sendEmail({
        to: toEmail,
        subject: template.subject,
        htmlBody: template.htmlBody,
        textBody: template.textBody,
        from: "compliance@complianceplatform.com"
      });

      return { success: true, messageId: result.messageId };
    } catch (error) {
      console.error("Follow-up email error:", error);
      return { success: false };
    }
  }

  private generateFollowUp1(listing: any) {
    return {
      subject: `Still time to fix your Amazon listing - ${listing.asin}`,
      htmlBody: `<p>Hi again,</p><p>Just checking if you had a chance to review the compliance issues we found in your listing. The violations we identified could impact your ranking and sales.</p><p><a href="https://complianceplatform.com/order?asin=${listing.asin}">Fix them now with 20% off</a></p>`,
      textBody: `Still time to fix your Amazon listing violations. 20% off this week: https://complianceplatform.com/order?asin=${listing.asin}`
    };
  }

  private generateFollowUp2(listing: any) {
    return {
      subject: `Last chance: Amazon compliance fix for ${listing.asin}`,
      htmlBody: `<p>Amazon's algorithm is getting stricter about compliance violations. Don't let policy issues hurt your sales.</p><p><a href="https://complianceplatform.com/order?asin=${listing.asin}">Get your listing fixed today</a></p>`,
      textBody: `Don't let compliance violations hurt your Amazon sales. Get fixed: https://complianceplatform.com/order?asin=${listing.asin}`
    };
  }

  private generateFinalFollowUp(listing: any) {
    return {
      subject: `Final notice: Amazon listing compliance`,
      htmlBody: `<p>This is our final reminder about the compliance issues in your Amazon listing.</p><p>If you'd prefer not to receive these alerts, you can <a href="#">unsubscribe here</a>.</p>`,
      textBody: `Final reminder about your Amazon listing compliance issues. Unsubscribe if you're not interested.`
    };
  }
}