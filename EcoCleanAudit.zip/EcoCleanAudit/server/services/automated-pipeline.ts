import { AmazonScraper } from "./amazon-scraper";
import { OpenAIService } from "./openai";
import { RiskDictionaryService } from "./risk-dictionary";
import { SellerContactService } from "./seller-contact";
import { OutreachAutomationService } from "./outreach-automation";
import { storage } from "../storage";
import { DefaultPDFRenderer } from "../adapters/defaults";
import { InsertListing, InsertAudit, InsertPdf, InsertOutreach, InsertEvent } from "@shared/schema";

/**
 * Fully Automated Lead Pipeline
 * 100% automated: scan → flag → audit → PDF → outreach
 */
export class AutomatedPipelineService {
  private scraper = new AmazonScraper();
  private auditService = new OpenAIService();
  private pdfRenderer = new DefaultPDFRenderer();
  private outreachService = new OutreachAutomationService();

  /**
   * Main pipeline entry point - fully automated keyword/category scan
   */
  async runAutomatedScan(config: {
    keywords: string;
    category?: string;
    maxResults?: number;
    enableOutreach?: boolean;
  }): Promise<{
    totalScanned: number;
    flaggedListings: number;
    auditedListings: number;
    pdfsGenerated: number;
    outreachSent: number;
    leads: Array<{
      id: string;
      asin: string;
      title: string;
      violationCount: number;
      riskLevel: string;
      status: string;
    }>;
  }> {
    console.log(`🚀 Starting automated pipeline for: "${config.keywords}"`);
    
    const results = {
      totalScanned: 0,
      flaggedListings: 0,
      auditedListings: 0,
      pdfsGenerated: 0,
      outreachSent: 0,
      leads: []
    };

    try {
      // Step 1: Scrape Amazon listings
      console.log("📡 Step 1: Scraping Amazon listings...");
      const products = await this.scraper.searchProducts(
        config.keywords,
        config.maxResults || 20
      );
      results.totalScanned = products.length;
      console.log(`Found ${products.length} products to analyze`);

      // Step 2: Flag detection using risk dictionary
      console.log("🚩 Step 2: Detecting risky listings...");
      const flaggedProducts = [];
      
      for (const product of products) {
        const flagResult = RiskDictionaryService.flagListing(
          config.category || product.category,
          product.title,
          product.bullets,
          product.description
        );

        if (flagResult.isFlagged) {
          flaggedProducts.push({
            ...product,
            riskLevel: flagResult.riskLevel,
            flaggedPhrases: flagResult.flaggedPhrases
          });
        }
      }
      
      results.flaggedListings = flaggedProducts.length;
      console.log(`🚩 Flagged ${flaggedProducts.length} listings for compliance issues`);

      // Step 3: Process each flagged listing through full pipeline
      for (const flaggedProduct of flaggedProducts) {
        try {
          const lead = await this.processFlaggedListing(flaggedProduct, config.enableOutreach);
          results.leads.push(lead);
          
          if (lead.status.includes("audited")) results.auditedListings++;
          if (lead.status.includes("pdf")) results.pdfsGenerated++;
          if (lead.status.includes("contacted")) results.outreachSent++;
          
        } catch (error) {
          console.error(`Error processing ${flaggedProduct.asin}:`, error);
        }
      }

      console.log(`✅ Pipeline complete: ${results.flaggedListings} leads generated`);
      return results;

    } catch (error) {
      console.error("Automated pipeline error:", error);
      throw new Error(`Pipeline failed: ${error.message}`);
    }
  }

  /**
   * Process a single flagged listing through the complete pipeline
   */
  private async processFlaggedListing(
    product: any,
    enableOutreach: boolean = true
  ): Promise<{
    id: string;
    asin: string;
    title: string;
    violationCount: number;
    riskLevel: string;
    status: string;
  }> {
    console.log(`🔍 Processing ${product.asin}: ${product.title.substring(0, 50)}...`);

    // Create listing record
    const listing: InsertListing = {
      title: product.title,
      url: product.url,
      asin: product.asin,
      category: product.category,
      bullets: product.bullets,
      description: product.description,
      images: product.images || [],
      sellerName: product.sellerName || "Unknown Seller",
      sellerUrl: product.sellerUrl,
      state: "new"
    };

    const savedListing = await storage.createListing(listing);
    
    // Update state: scraped
    await storage.updateListingState(savedListing.id, "scraped");

    // Step 3A: AI-powered compliance audit
    console.log(`🤖 Auditing ${product.asin} for compliance violations...`);
    
    const auditResult = await this.auditService.auditListing({
      title: product.title,
      category: product.category,
      bullets: product.bullets,
      description: product.description
    });

    // Save audit results
    const audit: InsertAudit = {
      listingId: savedListing.id,
      modelOrEngine: "gpt-4o",
      findings: auditResult.violations,
      summary: auditResult.summary
    };

    const savedAudit = await storage.createAudit(audit);
    
    // Update state: audited
    await storage.updateListingState(savedListing.id, "audited");

    let pdfUrl = null;
    let contactResult = null;

    // Step 3B: Generate PDF fix-pack report
    if (auditResult.violations.length > 0) {
      console.log(`📄 Generating PDF report for ${product.asin}...`);
      
      const pdfData = await this.pdfRenderer.generatePDF({
        listing: savedListing,
        audit: savedAudit,
        findings: auditResult.violations
      });

      const pdf: InsertPdf = {
        listingId: savedListing.id,
        url: pdfData.url,
        bytes: pdfData.bytes
      };

      await storage.createPdf(pdf);
      pdfUrl = pdfData.url;
      
      // Update state: pdf_ready
      await storage.updateListingState(savedListing.id, "pdf_ready");

      // Step 3C: Seller contact discovery and outreach
      if (enableOutreach) {
        console.log(`📧 Finding contact for seller: ${product.sellerName}...`);
        
        contactResult = await SellerContactService.findSellerContact(
          product.sellerName,
          product.sellerUrl
        );

        if (contactResult.email) {
          console.log(`📤 Sending outreach to ${contactResult.email}...`);
          
          const topViolation = auditResult.violations
            .sort((a, b) => {
              const severityOrder = { critical: 4, high: 3, moderate: 2, low: 1 };
              return severityOrder[b.severity] - severityOrder[a.severity];
            })[0];

          const emailResult = await this.outreachService.sendOutreach(
            contactResult.email,
            {
              title: product.title,
              asin: product.asin,
              category: product.category,
              violationCount: auditResult.violations.length,
              topViolation
            },
            pdfUrl,
            product.sellerName
          );

          // Save outreach record
          const outreach: InsertOutreach = {
            listingId: savedListing.id,
            channel: "email",
            toAddress: contactResult.email,
            subject: `Amazon Listing Compliance Issue - ${product.asin}`,
            body: "Automated compliance outreach",
            status: emailResult.success ? "sent" : "failed",
            providerMsgId: emailResult.messageId
          };

          await storage.createOutreach(outreach);
          
          // Update state: contacted
          await storage.updateListingState(savedListing.id, "contacted");
        } else {
          // Update state: outreach_queued (couldn't find contact)
          await storage.updateListingState(savedListing.id, "outreach_queued");
        }
      }
    }

    // Log pipeline event
    const event: InsertEvent = {
      type: "pipeline_processed",
      listingId: savedListing.id,
      payload: {
        violationCount: auditResult.violations.length,
        riskLevel: product.riskLevel,
        pdfGenerated: !!pdfUrl,
        contactFound: !!contactResult?.email,
        outreachSent: !!contactResult?.email && enableOutreach
      }
    };

    await storage.createEvent(event);

    return {
      id: savedListing.id,
      asin: product.asin,
      title: product.title,
      violationCount: auditResult.violations.length,
      riskLevel: product.riskLevel,
      status: savedListing.state || "processed"
    };
  }

  /**
   * Schedule automated scans (for admin configuration)
   */
  async scheduleAutomatedScan(config: {
    keywords: string[];
    categories: string[];
    frequency: "daily" | "weekly" | "monthly";
    maxResultsPerScan: number;
  }): Promise<{ scheduledJobs: number }> {
    // Placeholder for job scheduling system integration
    // Would integrate with services like:
    // - AWS EventBridge
    // - Google Cloud Scheduler  
    // - Cron jobs
    // - Bull Queue (Redis-based)
    
    console.log("📅 Scheduling automated scans:", config);
    
    // For now, return scheduled job count
    const totalJobs = config.keywords.length * config.categories.length;
    
    return { scheduledJobs: totalJobs };
  }

  /**
   * Get pipeline performance metrics
   */
  async getPipelineMetrics(timeRange: "24h" | "7d" | "30d" = "24h"): Promise<{
    scansRun: number;
    listingsProcessed: number;
    violationsFound: number;
    leadsGenerated: number;
    outreachSent: number;
    conversionRate: number;
    averageViolationsPerListing: number;
  }> {
    // Calculate date range
    const now = new Date();
    const ranges = {
      "24h": 24 * 60 * 60 * 1000,
      "7d": 7 * 24 * 60 * 60 * 1000,
      "30d": 30 * 24 * 60 * 60 * 1000
    };
    
    const startDate = new Date(now.getTime() - ranges[timeRange]);
    
    // Get metrics from storage
    // This would be implemented with proper database aggregation queries
    const listings = await storage.getListings({ page: 1, limit: 1000 });
    const filteredListings = listings.data.filter(l => 
      l.createdAt && new Date(l.createdAt) >= startDate
    );
    
    const totalViolations = filteredListings.reduce((sum, listing) => {
      // Would need to get audit data for each listing
      return sum + 0; // Placeholder
    }, 0);

    return {
      scansRun: 1, // Placeholder - would track actual scan events
      listingsProcessed: filteredListings.length,
      violationsFound: totalViolations,
      leadsGenerated: filteredListings.filter(l => l.state !== "new").length,
      outreachSent: filteredListings.filter(l => l.state === "contacted").length,
      conversionRate: 0.15, // Placeholder - would calculate from actual data
      averageViolationsPerListing: filteredListings.length > 0 ? totalViolations / filteredListings.length : 0
    };
  }
}