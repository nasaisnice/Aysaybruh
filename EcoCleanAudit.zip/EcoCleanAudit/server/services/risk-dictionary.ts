import { RiskDictionary } from "@shared/schema";

/**
 * Risk Dictionary Service
 * Configurable phrases per category that indicate potential compliance issues
 */
export class RiskDictionaryService {
  private static dictionary: RiskDictionary = {
    categories: {
      "Health & Personal Care": {
        phrases: {
          critical: [
            "FDA approved",
            "FDA certified", 
            "prevents COVID-19",
            "prevents coronavirus",
            "prevents disease",
            "prevents cancer",
            "cures",
            "heals",
            "treats diabetes",
            "treats depression",
            "doctor recommended",
            "clinically proven",
            "medical grade"
          ],
          high: [
            "kills 99.9%",
            "eliminates 100%",
            "instantly kills",
            "destroys viruses",
            "scientifically proven",
            "laboratory tested",
            "hospital grade",
            "pharmaceutical quality"
          ],
          moderate: [
            "all natural",
            "chemical free",
            "toxin free",
            "100% safe",
            "guaranteed results",
            "miraculous",
            "revolutionary formula"
          ],
          low: [
            "may help",
            "supports",
            "promotes",
            "maintains",
            "assists"
          ]
        }
      },
      "Baby & Child Care": {
        phrases: {
          critical: [
            "FDA approved",
            "pediatrician approved",
            "prevents SIDS",
            "prevents allergies",
            "hypoallergenic guaranteed",
            "medically tested"
          ],
          high: [
            "100% safe for babies",
            "chemical free",
            "toxin free",
            "clinically tested",
            "dermatologist tested"
          ],
          moderate: [
            "all natural",
            "organic certified",
            "gentle formula",
            "tear free"
          ],
          low: [
            "suitable for sensitive skin",
            "mild formula"
          ]
        }
      },
      "Electronics": {
        phrases: {
          critical: [
            "FCC approved",
            "CE certified",
            "prevents radiation",
            "blocks EMF 100%",
            "government tested"
          ],
          high: [
            "military grade",
            "professional quality",
            "commercial grade",
            "industrial strength"
          ],
          moderate: [
            "lifetime guarantee",
            "never breaks",
            "indestructible",
            "waterproof guaranteed"
          ],
          low: [
            "durable design",
            "reliable performance"
          ]
        }
      },
      "Home & Garden": {
        phrases: {
          critical: [
            "EPA approved",
            "kills 100% of pests",
            "eliminates mold completely",
            "non-toxic guaranteed",
            "safe around children"
          ],
          high: [
            "chemical free",
            "organic certified",
            "environmentally safe",
            "biodegradable"
          ],
          moderate: [
            "all natural",
            "eco-friendly",
            "green formula"
          ],
          low: [
            "suitable for indoor use",
            "gentle on plants"
          ]
        }
      }
    }
  };

  /**
   * Check if a listing contains risky phrases
   */
  static flagListing(category: string, title: string, bullets: string[], description: string): {
    isFlagged: boolean;
    riskLevel: "low" | "moderate" | "high" | "critical" | null;
    flaggedPhrases: Array<{ phrase: string; severity: string; location: string }>;
  } {
    const categoryDict = this.dictionary.categories[category];
    if (!categoryDict) {
      return { isFlagged: false, riskLevel: null, flaggedPhrases: [] };
    }

    const flaggedPhrases: Array<{ phrase: string; severity: string; location: string }> = [];
    const content = {
      title: title.toLowerCase(),
      bullets: bullets.join(" ").toLowerCase(),
      description: description.toLowerCase()
    };

    let highestRisk: "low" | "moderate" | "high" | "critical" | null = null;

    // Check each severity level
    for (const [severity, phrases] of Object.entries(categoryDict.phrases)) {
      for (const phrase of phrases) {
        const lowerPhrase = phrase.toLowerCase();
        
        // Check title
        if (content.title.includes(lowerPhrase)) {
          flaggedPhrases.push({ phrase, severity, location: "title" });
          highestRisk = this.getHigherRisk(highestRisk, severity as any);
        }
        
        // Check bullets
        if (content.bullets.includes(lowerPhrase)) {
          flaggedPhrases.push({ phrase, severity, location: "bullets" });
          highestRisk = this.getHigherRisk(highestRisk, severity as any);
        }
        
        // Check description
        if (content.description.includes(lowerPhrase)) {
          flaggedPhrases.push({ phrase, severity, location: "description" });
          highestRisk = this.getHigherRisk(highestRisk, severity as any);
        }
      }
    }

    return {
      isFlagged: flaggedPhrases.length > 0,
      riskLevel: highestRisk,
      flaggedPhrases
    };
  }

  private static getHigherRisk(
    current: "low" | "moderate" | "high" | "critical" | null, 
    new_risk: "low" | "moderate" | "high" | "critical"
  ): "low" | "moderate" | "high" | "critical" {
    const riskLevels = { low: 1, moderate: 2, high: 3, critical: 4 };
    const currentLevel = current ? riskLevels[current] : 0;
    const newLevel = riskLevels[new_risk];
    
    return newLevel > currentLevel ? new_risk : (current || "low");
  }

  /**
   * Get the risk dictionary for admin configuration
   */
  static getDictionary(): RiskDictionary {
    return this.dictionary;
  }

  /**
   * Update the risk dictionary (for admin interface)
   */
  static updateDictionary(newDictionary: RiskDictionary): void {
    this.dictionary = newDictionary;
  }
}