import type { 
  ListingSourceAdapter, 
  AuditEngineAdapter, 
  SignalEngineAdapter,
  PdfRendererAdapter,
  StorageAdapter,
  EmailAdapter,
  MetricsAdapter,
  QueueAdapter 
} from "../adapters/interfaces";
import type { Listing, InsertListing, InsertAudit, InsertPdf, InsertOutreach, InsertEvent } from "@shared/schema";
import { storage } from "../storage";

export class LeadPipelineService {
  constructor(
    private listingSource: ListingSourceAdapter,
    private signalEngine: SignalEngineAdapter,
    private auditEngine: AuditEngineAdapter,
    private pdfRenderer: PdfRendererAdapter,
    private storageAdapter: StorageAdapter,
    private emailAdapter: EmailAdapter,
    private metrics: MetricsAdapter,
    private queue: QueueAdapter
  ) {
    this.setupQueueProcessors();
  }

  // Main entry point: discover and process leads
  async discoverLeads(keywords: string, options: {
    category?: string;
    maxResults?: number;
  } = {}): Promise<{ leadCount: number; processedCount: number }> {
    const startTime = Date.now();
    
    try {
      await this.metrics.logEvent({
        type: 'lead_discovery_started',
        payload: { keywords, options },
      });

      // Step 1: Search for listings
      const listingData = await this.listingSource.searchListings(keywords, options);
      await this.metrics.incrementCounter('listings_discovered', { source: 'amazon' });

      let processedCount = 0;

      for (const data of listingData) {
        try {
          // Step 2: Analyze risk signals
          const riskAnalysis = await this.signalEngine.analyzeRiskSignals(data);
          
          // Only proceed with listings that have moderate+ risk
          if (!riskAnalysis.severity || ['low'].includes(riskAnalysis.severity)) {
            continue;
          }

          // Step 3: Create lead record
          const listing: InsertListing = {
            asin: data.asin,
            url: data.url,
            title: data.title,
            bullets: data.bullets,
            description: data.description,
            images: data.images,
            category: data.category,
            sellerName: data.sellerName,
            sellerStoreUrl: data.sellerStoreUrl,
            sellerContactUrl: data.sellerContactUrl,
            signals: riskAnalysis.signals,
            severity: riskAnalysis.severity,
            state: 'scraped',
          };

          const listingId = await storage.createListing(listing);
          
          await this.metrics.logEvent({
            type: 'lead_created',
            listingId,
            payload: { severity: riskAnalysis.severity, score: riskAnalysis.score },
          });

          // Queue for audit processing
          await this.queue.addJob('audit-pipeline', 'audit-listing', { listingId }, {
            attempts: 3,
            backoff: { type: 'exponential', delay: 2000 },
          });

          processedCount++;

        } catch (error) {
          console.error(`Failed to process listing ${data.url}:`, error);
          await this.metrics.incrementCounter('listing_processing_errors');
        }
      }

      const duration = Date.now() - startTime;
      await this.metrics.recordDuration('lead_discovery_duration', duration);
      
      await this.metrics.logEvent({
        type: 'lead_discovery_completed',
        payload: { leadCount: listingData.length, processedCount, duration },
      });

      return { leadCount: listingData.length, processedCount };

    } catch (error) {
      await this.metrics.logEvent({
        type: 'lead_discovery_failed',
        payload: { error: error instanceof Error ? error.message : 'Unknown error' },
      });
      throw error;
    }
  }

  // Process individual listing through the pipeline
  async processListing(listingId: string): Promise<void> {
    const listing = await storage.getListingById(listingId);
    if (!listing) throw new Error(`Listing ${listingId} not found`);

    try {
      // Step 1: Audit the listing
      await this.auditListing(listingId);
      
      // Step 2: Generate PDF report
      await this.generatePdfReport(listingId);
      
      // Step 3: Queue outreach
      await this.queue.addJob('outreach-pipeline', 'send-outreach', { listingId }, {
        delay: 5000, // Wait 5 seconds before sending outreach
        attempts: 3,
      });

    } catch (error) {
      await this.metrics.logEvent({
        type: 'listing_processing_failed',
        listingId,
        payload: { error: error instanceof Error ? error.message : 'Unknown error' },
      });
      throw error;
    }
  }

  private async auditListing(listingId: string): Promise<void> {
    const listing = await storage.getListingById(listingId);
    if (!listing) throw new Error(`Listing ${listingId} not found`);

    const auditResult = await this.auditEngine.auditListing({
      title: listing.title,
      bullets: listing.bullets || [],
      description: listing.description,
      category: listing.category,
    });

    // Store audit results
    const audit: InsertAudit = {
      listingId,
      modelOrEngine: auditResult.modelOrEngine,
      findings: auditResult.findings,
      summary: auditResult.summary,
    };

    await storage.createAudit(audit);

    // Update listing state and severity based on findings
    const maxSeverity = this.getMaxSeverity(auditResult.findings.map(f => f.severity));
    await storage.updateListingState(listingId, 'audited', maxSeverity);

    await this.metrics.logEvent({
      type: 'listing_audited',
      listingId,
      payload: { 
        findings: auditResult.findings.length,
        severity: maxSeverity,
      },
    });
  }

  private async generatePdfReport(listingId: string): Promise<void> {
    const listing = await storage.getListingById(listingId);
    const audit = await storage.getAuditByListingId(listingId);
    
    if (!listing || !audit) {
      throw new Error(`Missing listing or audit data for ${listingId}`);
    }

    // Get current settings for branding and pricing
    const settings = await storage.getSettings();
    
    const pdfData = await this.pdfRenderer.generateComplianceReport({
      listing,
      findings: audit.findings || [],
      branding: settings.branding,
      pricing: settings.pricing,
    });

    // Upload PDF to storage
    const filename = `compliance-report-${listingId}-${Date.now()}.pdf`;
    const uploadResult = await this.storageAdapter.uploadFile(
      pdfData.buffer, 
      `reports/${filename}`, 
      'application/pdf'
    );

    // Store PDF record
    const pdf: InsertPdf = {
      listingId,
      url: uploadResult.url,
      bytes: pdfData.buffer.length,
    };

    await storage.createPdf(pdf);
    await storage.updateListingState(listingId, 'pdf_ready');

    await this.metrics.logEvent({
      type: 'pdf_generated',
      listingId,
      payload: { 
        url: uploadResult.url,
        size: pdfData.buffer.length,
      },
    });
  }

  private async sendOutreach(listingId: string): Promise<void> {
    const listing = await storage.getListingById(listingId);
    const audit = await storage.getAuditByListingId(listingId);
    const pdf = await storage.getPdfByListingId(listingId);
    
    if (!listing || !audit || !pdf) {
      throw new Error(`Missing data for outreach ${listingId}`);
    }

    // Skip if no contact information
    if (!listing.sellerContactUrl && !this.extractEmailFromUrl(listing.sellerStoreUrl)) {
      await this.metrics.logEvent({
        type: 'outreach_skipped',
        listingId,
        payload: { reason: 'no_contact_info' },
      });
      return;
    }

    const settings = await storage.getSettings();
    const topFinding = audit.findings?.[0];
    
    if (!topFinding) return;

    // Render email template
    const emailContent = this.renderOutreachEmail({
      listing,
      topFinding,
      pdfUrl: pdf.url,
      settings,
    });

    const emailAddress = this.extractEmailFromUrl(listing.sellerStoreUrl) || 
                        this.extractEmailFromUrl(listing.sellerContactUrl);

    if (emailAddress) {
      // Send email
      const result = await this.emailAdapter.sendEmail({
        to: emailAddress,
        subject: emailContent.subject,
        html: emailContent.html,
        trackingId: listingId,
      });

      // Store outreach record
      const outreach: InsertOutreach = {
        listingId,
        channel: 'email',
        toAddress: emailAddress,
        subject: emailContent.subject,
        body: emailContent.html,
        status: result.status === 'sent' ? 'sent' : 'queued',
        providerMsgId: result.messageId,
      };

      await storage.createOutreach(outreach);
      await storage.updateListingState(listingId, 'contacted');

      await this.metrics.logEvent({
        type: 'outreach_sent',
        listingId,
        payload: { 
          channel: 'email',
          messageId: result.messageId,
          status: result.status,
        },
      });
    }
  }

  private renderOutreachEmail(params: {
    listing: Listing;
    topFinding: any;
    pdfUrl: string;
    settings: any;
  }): { subject: string; html: string } {
    const { listing, topFinding, pdfUrl, settings } = params;
    
    const subject = `Quick fix to reduce "${listing.title}" compliance risk (found ${topFinding.severity})`;
    
    const html = `
      <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
        <div style="background: ${settings.branding.primary_color}; color: white; padding: 20px; text-align: center;">
          <h1>${settings.branding.company_name}</h1>
        </div>
        
        <div style="padding: 30px;">
          <p>Hi there,</p>
          
          <p>I noticed your product "<strong>${listing.title}</strong>" has some compliance risks that could impact your Amazon listing.</p>
          
          <div style="background: #fee; border: 1px solid #fcc; padding: 15px; border-radius: 5px; margin: 20px 0;">
            <strong>🚨 ${topFinding.severity.toUpperCase()} Risk Found:</strong><br>
            "${topFinding.claim_text}" - ${topFinding.why_it_fails}
          </div>
          
          <p>I've prepared a detailed compliance report for you: <a href="${pdfUrl}">View Report</a></p>
          
          <div style="background: #f9f9f9; padding: 20px; border-radius: 5px; margin: 20px 0;">
            <h3>Quick Fix Options:</h3>
            <p><strong>Option 1:</strong> Complete audit fix - $${settings.pricing.audit_fix_price} <a href="${settings.outreach.checkout_link}">Get Started</a></p>
            <p><strong>Option 2:</strong> Ongoing monitoring - $${settings.pricing.monthly_retainer}/month <a href="${settings.outreach.booking_link}">Book Call</a></p>
          </div>
          
          <p>Best regards,<br>${settings.branding.company_name}</p>
          
          <div style="font-size: 12px; color: #666; margin-top: 30px; border-top: 1px solid #eee; padding-top: 15px;">
            This report is for informational purposes only and does not constitute legal advice.
          </div>
        </div>
      </div>
    `;

    return { subject, html };
  }

  private extractEmailFromUrl(url?: string | null): string | null {
    if (!url) return null;
    // Simple email extraction - in production, would use more sophisticated methods
    const emailRegex = /([a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,})/;
    const match = url.match(emailRegex);
    return match ? match[1] : null;
  }

  private getMaxSeverity(severities: string[]): "low" | "moderate" | "high" | "critical" | null {
    const order = { critical: 4, high: 3, moderate: 2, low: 1 };
    let max = null;
    let maxScore = 0;

    for (const severity of severities) {
      const score = order[severity as keyof typeof order] || 0;
      if (score > maxScore) {
        maxScore = score;
        max = severity as any;
      }
    }

    return max;
  }

  private setupQueueProcessors(): void {
    // Audit pipeline processor
    this.queue.process('audit-pipeline', 2, async (job) => {
      await this.auditListing(job.data.listingId);
      
      // Queue PDF generation
      await this.queue.addJob('pdf-pipeline', 'generate-pdf', { listingId: job.data.listingId });
    });

    // PDF pipeline processor  
    this.queue.process('pdf-pipeline', 1, async (job) => {
      await this.generatePdfReport(job.data.listingId);
      
      // Queue outreach
      await this.queue.addJob('outreach-pipeline', 'send-outreach', { listingId: job.data.listingId }, {
        delay: 2000, // Wait 2 seconds
      });
    });

    // Outreach pipeline processor
    this.queue.process('outreach-pipeline', 1, async (job) => {
      await this.sendOutreach(job.data.listingId);
    });
  }
}