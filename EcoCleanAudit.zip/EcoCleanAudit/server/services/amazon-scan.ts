import type { AmazonSearch, ScanResult, AmazonProduct, Listing } from "@shared/schema";
import { amazonScraper } from "./amazon-scraper";
import { runComplianceAudit } from "./openai";

export class AmazonScanService {
  async scanAmazonListings(searchParams: AmazonSearch): Promise<ScanResult> {
    try {
      console.log(`Starting Amazon scan for: "${searchParams.keywords}"`);
      
      // Step 1: Search Amazon for products
      const products = await amazonScraper.searchProducts(searchParams);
      console.log(`Found ${products.length} products to analyze`);

      if (products.length === 0) {
        return {
          searchQuery: searchParams.keywords,
          totalProducts: 0,
          flaggedProducts: [],
          summary: {
            totalScanned: 0,
            totalFlagged: 0,
            criticalViolations: 0,
            highViolations: 0,
            moderateViolations: 0,
            lowViolations: 0,
          }
        };
      }

      // Step 2: Get detailed product information and analyze each
      const flaggedProducts = [];
      let totalScanned = 0;
      let criticalViolations = 0;
      let highViolations = 0;
      let moderateViolations = 0;
      let lowViolations = 0;

      for (const product of products) {
        try {
          console.log(`Analyzing product: ${product.title}`);
          
          // Get detailed product information
          const details = await amazonScraper.getProductDetails(product.asin);
          
          // Merge product with details
          const completeProduct: AmazonProduct = {
            ...product,
            bullets: details.bullets || [],
            description: details.description || product.title,
            category: this.determineCategory(product.title, details.bullets || [])
          };

          // Convert to listing format for analysis
          const listing: Listing = {
            category: completeProduct.category,
            title: completeProduct.title,
            bullets: completeProduct.bullets,
            description: completeProduct.description
          };

          // Skip analysis if we don't have enough content
          if (!listing.title.trim() || (listing.bullets.length === 0 && !listing.description.trim())) {
            console.log(`Skipping ${product.asin} - insufficient content`);
            continue;
          }

          // Run compliance analysis
          const analysis = await runComplianceAudit(listing);
          totalScanned++;

          // Only include if violations found
          if (analysis.violations.length > 0) {
            flaggedProducts.push({
              product: completeProduct,
              analysis
            });

            // Update violation counts
            criticalViolations += analysis.summary.critical;
            highViolations += analysis.summary.high;
            moderateViolations += analysis.summary.moderate;
            lowViolations += analysis.summary.low;
          }

          // Add delay to avoid rate limiting
          await this.delay(1000);

        } catch (error) {
          console.error(`Error analyzing product ${product.asin}:`, error);
          // Continue with next product
        }
      }

      console.log(`Scan complete. ${totalScanned} products analyzed, ${flaggedProducts.length} flagged`);

      return {
        searchQuery: searchParams.keywords,
        totalProducts: products.length,
        flaggedProducts,
        summary: {
          totalScanned,
          totalFlagged: flaggedProducts.length,
          criticalViolations,
          highViolations,
          moderateViolations,
          lowViolations,
        }
      };

    } catch (error) {
      console.error("Amazon scan error:", error);
      throw new Error(`Failed to scan Amazon listings: ${error instanceof Error ? error.message : 'Unknown error'}`);
    }
  }

  private determineCategory(title: string, bullets: string[]): string {
    const text = `${title} ${bullets.join(' ')}`.toLowerCase();
    
    // Simple keyword-based category detection
    if (text.includes('disinfect') || text.includes('clean') || text.includes('sanitiz') || text.includes('antibacterial')) {
      return 'Household Cleaners';
    }
    
    if (text.includes('supplement') || text.includes('vitamin') || text.includes('protein') || text.includes('probiotic')) {
      return 'Dietary Supplements';
    }
    
    if (text.includes('pet') || text.includes('dog') || text.includes('cat') || text.includes('puppy') || text.includes('kitten')) {
      return 'Pet Products';
    }
    
    if (text.includes('shampoo') || text.includes('lotion') || text.includes('cream') || text.includes('skincare') || text.includes('beauty')) {
      return 'Personal Care';
    }
    
    if (text.includes('garden') || text.includes('plant') || text.includes('seed') || text.includes('fertilizer')) {
      return 'Home & Garden';
    }
    
    return 'General';
  }

  private delay(ms: number): Promise<void> {
    return new Promise(resolve => setTimeout(resolve, ms));
  }
}

export const amazonScanService = new AmazonScanService();