import type { 
  ListingSourceAdapter, 
  AuditEngineAdapter, 
  SignalEngineAdapter,
  PdfRendererAdapter,
  StorageAdapter,
  EmailAdapter,
  MetricsAdapter,
  QueueAdapter,
  ListingData 
} from "./interfaces";
import type { Listing, Finding } from "@shared/schema";
import { runComplianceAudit } from "../services/openai";

// Default Amazon Listing Source
export class AmazonListingSource implements ListingSourceAdapter {
  async searchListings(keywords: string, options: {
    category?: string;
    maxResults?: number;
    marketplace?: string;
  } = {}): Promise<ListingData[]> {
    const { category, maxResults = 10 } = options;
    
    // Use existing Amazon scraper logic
    const searchUrl = this.buildSearchUrl(keywords, category);
    
    const response = await fetch(searchUrl, {
      headers: {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36',
        'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8',
      }
    });

    if (!response.ok) {
      throw new Error(`Amazon search failed: ${response.status}`);
    }

    const html = await response.text();
    return this.parseSearchResults(html, maxResults);
  }

  async getListingDetails(url: string): Promise<ListingData> {
    const response = await fetch(url, {
      headers: {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36',
      }
    });

    if (!response.ok) {
      throw new Error(`Failed to fetch listing: ${response.status}`);
    }

    const html = await response.text();
    return this.parseProductDetails(html, url);
  }

  private buildSearchUrl(keywords: string, category?: string): string {
    const params = new URLSearchParams({
      k: keywords,
      ref: "sr_pg_1"
    });

    if (category) {
      const categoryMap: Record<string, string> = {
        "Household Cleaners": "garden",
        "Dietary Supplements": "hpc",
        "Pet Products": "pets",
        "Personal Care": "hpc",
        "Home & Garden": "garden"
      };
      
      if (categoryMap[category]) {
        params.append("rh", `n:${categoryMap[category]}`);
      }
    }

    return `https://www.amazon.com/s?${params.toString()}`;
  }

  private parseSearchResults(html: string, maxResults: number): ListingData[] {
    const results: ListingData[] = [];
    
    // Extract ASINs and basic data using regex patterns
    const asinMatches = html.match(/data-asin="([A-Z0-9]{10})"/g) || [];
    const asins = asinMatches.map(match => match.match(/data-asin="([A-Z0-9]{10})"/)?.[1]).filter(Boolean) as string[];
    
    const titleMatches = html.match(/<h2[^>]*><a[^>]*><span[^>]*>([^<]+)<\/span>/g) || [];
    const titles = titleMatches.map(match => {
      const titleMatch = match.match(/<span[^>]*>([^<]+)<\/span>/);
      return titleMatch ? this.cleanText(titleMatch[1]) : '';
    }).filter(Boolean);

    const urlMatches = html.match(/href="([^"]*\/dp\/[A-Z0-9]{10}[^"]*)"/g) || [];
    const urls = urlMatches.map(match => {
      const urlMatch = match.match(/href="([^"]*)"/);
      if (urlMatch) {
        const url = urlMatch[1];
        return url.startsWith('/') ? `https://www.amazon.com${url}` : url;
      }
      return '';
    }).filter(Boolean);

    const limit = Math.min(asins.length, titles.length, urls.length, maxResults);
    
    for (let i = 0; i < limit; i++) {
      if (asins[i] && titles[i] && urls[i]) {
        results.push({
          asin: asins[i],
          url: urls[i],
          title: titles[i],
          bullets: [],
          description: '',
          images: [],
          category: 'General',
        });
      }
    }

    return results;
  }

  private parseProductDetails(html: string, url: string): ListingData {
    const asinMatch = url.match(/\/dp\/([A-Z0-9]{10})/);
    const asin = asinMatch ? asinMatch[1] : '';
    
    const titleMatch = html.match(/<span[^>]*id="productTitle"[^>]*>([^<]+)</);
    const title = titleMatch ? this.cleanText(titleMatch[1]) : '';
    
    // Extract bullet points
    const bulletMatches = html.match(/<span class="a-list-item">([^<]+)</g) || [];
    const bullets = bulletMatches
      .map(match => {
        const bulletMatch = match.match(/<span class="a-list-item">([^<]+)/);
        return bulletMatch ? this.cleanText(bulletMatch[1]) : '';
      })
      .filter(bullet => bullet.length > 10 && !bullet.includes('Make sure'))
      .slice(0, 5);

    // Extract description
    let description = '';
    const descMatches = html.match(/<div[^>]*feature[^>]*>([^<]+)</g) || [];
    if (descMatches.length > 0 && descMatches[0]) {
      description = this.cleanText(descMatches[0].replace(/<[^>]*>/g, ''));
    }

    // Extract images
    const imageMatches = html.match(/"hiRes":"([^"]+)"/g) || [];
    const images = imageMatches.map(match => {
      const imgMatch = match.match(/"hiRes":"([^"]+)"/);
      return imgMatch ? imgMatch[1] : '';
    }).filter(Boolean).slice(0, 5);

    return {
      asin,
      url,
      title,
      bullets,
      description,
      images,
      category: this.determineCategory(title, bullets),
    };
  }

  private determineCategory(title: string, bullets: string[]): string {
    const text = `${title} ${bullets.join(' ')}`.toLowerCase();
    
    if (text.includes('disinfect') || text.includes('clean') || text.includes('sanitiz')) {
      return 'Household Cleaners';
    }
    if (text.includes('supplement') || text.includes('vitamin') || text.includes('protein')) {
      return 'Dietary Supplements';
    }
    if (text.includes('pet') || text.includes('dog') || text.includes('cat')) {
      return 'Pet Products';
    }
    if (text.includes('shampoo') || text.includes('lotion') || text.includes('cream')) {
      return 'Personal Care';
    }
    
    return 'General';
  }

  private cleanText(text: string): string {
    return text
      .replace(/&amp;/g, '&')
      .replace(/&lt;/g, '<')
      .replace(/&gt;/g, '>')
      .replace(/&quot;/g, '"')
      .replace(/&#x27;/g, "'")
      .replace(/\s+/g, ' ')
      .trim();
  }
}

// Default OpenAI Audit Engine
export class OpenAIAuditEngine implements AuditEngineAdapter {
  async auditListing(listing: Pick<Listing, 'title' | 'bullets' | 'description' | 'category'>): Promise<{
    findings: Finding[];
    summary: Record<string, any>;
    modelOrEngine: string;
  }> {
    const result = await runComplianceAudit({
      category: listing.category || 'General',
      title: listing.title,
      bullets: listing.bullets || [],
      description: listing.description || '',
    });

    return {
      findings: result.violations,
      summary: result.summary,
      modelOrEngine: 'gpt-4o',
    };
  }
}

// Default Risk Signal Engine
export class DefaultSignalEngine implements SignalEngineAdapter {
  private riskPhrases = {
    critical: [
      'kills covid', 'cures cancer', 'fda approved', 'medical grade',
      'treats disease', 'prevents illness', 'doctor recommended'
    ],
    high: [
      'kills 99.9%', 'eliminates all', 'completely safe', 'no side effects',
      'miracle cure', 'instant results', 'guaranteed'
    ],
    moderate: [
      'natural', 'organic', 'chemical-free', 'clinically tested',
      'laboratory proven', 'scientifically formulated'
    ],
    low: [
      'may help', 'supports', 'promotes', 'designed for'
    ]
  };

  async analyzeRiskSignals(listing: ListingData): Promise<{
    signals: Record<string, any>;
    severity: "low" | "moderate" | "high" | "critical" | null;
    score: number;
  }> {
    const text = `${listing.title} ${listing.bullets.join(' ')} ${listing.description || ''}`.toLowerCase();
    
    const signals: Record<string, any> = {};
    let maxSeverity: "low" | "moderate" | "high" | "critical" | null = null;
    let score = 0;

    // Check for risk phrases
    for (const [severity, phrases] of Object.entries(this.riskPhrases)) {
      const matches = phrases.filter(phrase => text.includes(phrase.toLowerCase()));
      if (matches.length > 0) {
        signals[`${severity}_phrases`] = matches;
        maxSeverity = this.getHigherSeverity(maxSeverity, severity as any);
        score += this.getSeverityScore(severity as any) * matches.length;
      }
    }

    // Additional signals
    signals.title_length = listing.title.length;
    signals.bullet_count = listing.bullets.length;
    signals.has_images = listing.images.length > 0;
    signals.category = listing.category;

    return {
      signals,
      severity: maxSeverity,
      score: Math.min(score, 100),
    };
  }

  private getHigherSeverity(
    current: "low" | "moderate" | "high" | "critical" | null,
    newSeverity: "low" | "moderate" | "high" | "critical"
  ): "low" | "moderate" | "high" | "critical" {
    const severityOrder = { low: 1, moderate: 2, high: 3, critical: 4 };
    if (!current) return newSeverity;
    return severityOrder[newSeverity] > severityOrder[current] ? newSeverity : current;
  }

  private getSeverityScore(severity: "low" | "moderate" | "high" | "critical"): number {
    const scores = { low: 1, moderate: 3, high: 7, critical: 15 };
    return scores[severity];
  }
}

// Simple in-memory implementations for development
export class InMemoryMetrics implements MetricsAdapter {
  private events: any[] = [];
  private counters: Map<string, number> = new Map();

  async logEvent(event: { type: string; listingId?: string; payload: Record<string, any>; timestamp?: Date }): Promise<void> {
    this.events.push({ ...event, timestamp: event.timestamp || new Date() });
  }

  async incrementCounter(metric: string, tags?: Record<string, string>): Promise<void> {
    const key = tags ? `${metric}:${JSON.stringify(tags)}` : metric;
    this.counters.set(key, (this.counters.get(key) || 0) + 1);
  }

  async recordDuration(metric: string, duration: number, tags?: Record<string, string>): Promise<void> {
    // Store duration metrics (simplified)
    await this.incrementCounter(`${metric}_duration`, tags);
  }

  async getDashboardMetrics(): Promise<any> {
    // Return mock metrics for development
    return {
      leads: { total: 150, new: 25, audited: 100, contacted: 75, replied: 30, won: 12 },
      severity: { critical: 8, high: 25, moderate: 45, low: 72 },
      conversion: { contact_rate: 0.75, reply_rate: 0.40, win_rate: 0.16 },
    };
  }
}

// Simple storage implementation (filesystem for development)
export class LocalStorageAdapter implements StorageAdapter {
  private baseUrl = process.env.BASE_URL || 'http://localhost:5000';
  private uploadDir = './uploads';

  async uploadFile(buffer: Buffer, key: string, contentType: string): Promise<{ url: string; key: string }> {
    const fs = await import('fs/promises');
    const path = await import('path');
    
    const fullPath = path.join(this.uploadDir, key);
    const dir = path.dirname(fullPath);
    
    // Ensure directory exists
    await fs.mkdir(dir, { recursive: true });
    await fs.writeFile(fullPath, buffer);
    
    return {
      url: `${this.baseUrl}/uploads/${key}`,
      key,
    };
  }

  async deleteFile(key: string): Promise<void> {
    const fs = await import('fs/promises');
    const path = await import('path');
    
    try {
      await fs.unlink(path.join(this.uploadDir, key));
    } catch (error) {
      // File might not exist, ignore
    }
  }

  async getSignedUrl(key: string, expiresIn = 3600): Promise<string> {
    // For local storage, just return the public URL
    return `${this.baseUrl}/uploads/${key}`;
  }
}

// Mock email adapter for development
export class MockEmailAdapter implements EmailAdapter {
  async sendEmail(params: {
    to: string;
    subject: string;
    html: string;
    text?: string;
    replyTo?: string;
    trackingId?: string;
  }): Promise<{ messageId: string; status: "sent" | "failed"; error?: string }> {
    console.log(`📧 Mock Email Sent to ${params.to}`);
    console.log(`Subject: ${params.subject}`);
    console.log(`Tracking ID: ${params.trackingId}`);
    
    return {
      messageId: `mock_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`,
      status: "sent",
    };
  }

  async handleWebhook(payload: any): Promise<{
    messageId: string;
    event: "delivered" | "bounced" | "replied" | "opened";
    data?: Record<string, any>;
  }> {
    return {
      messageId: payload.messageId || 'unknown',
      event: payload.event || 'delivered',
      data: payload,
    };
  }
}

// Simple in-memory queue for development
export class InMemoryQueue implements QueueAdapter {
  private queues: Map<string, any[]> = new Map();
  private processors: Map<string, Function> = new Map();

  async addJob<T = any>(queue: string, job: string, data: T, options: any = {}): Promise<void> {
    if (!this.queues.has(queue)) {
      this.queues.set(queue, []);
    }
    
    const jobData = {
      id: `${Date.now()}_${Math.random().toString(36).substr(2, 9)}`,
      name: job,
      data,
      attemptsMade: 0,
      ...options,
    };
    
    this.queues.get(queue)!.push(jobData);
    
    // Process immediately if processor exists
    const processor = this.processors.get(queue);
    if (processor) {
      setImmediate(() => this.processNext(queue));
    }
  }

  process<T = any>(queue: string, concurrency: number, processor: Function): void {
    this.processors.set(queue, processor);
    
    // Start processing existing jobs
    for (let i = 0; i < Math.min(concurrency, this.getQueueLength(queue)); i++) {
      setImmediate(() => this.processNext(queue));
    }
  }

  private async processNext(queue: string): Promise<void> {
    const jobs = this.queues.get(queue);
    const processor = this.processors.get(queue);
    
    if (!jobs || !processor || jobs.length === 0) return;
    
    const job = jobs.shift();
    if (!job) return;
    
    try {
      await processor(job);
    } catch (error) {
      console.error(`Job ${job.id} failed:`, error);
      job.attemptsMade++;
      
      if (job.attemptsMade < (job.attempts || 3)) {
        // Retry with exponential backoff
        const delay = Math.pow(2, job.attemptsMade) * 1000;
        setTimeout(() => {
          jobs.unshift(job);
          this.processNext(queue);
        }, delay);
      }
    }
    
    // Process next job
    if (jobs.length > 0) {
      setImmediate(() => this.processNext(queue));
    }
  }

  private getQueueLength(queue: string): number {
    return this.queues.get(queue)?.length || 0;
  }

  async getQueueStats(queue: string): Promise<{
    waiting: number;
    active: number;
    completed: number;
    failed: number;
    delayed: number;
  }> {
    return {
      waiting: this.getQueueLength(queue),
      active: 0,
      completed: 0,
      failed: 0,
      delayed: 0,
    };
  }
}