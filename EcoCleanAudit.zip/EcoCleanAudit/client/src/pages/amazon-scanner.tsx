import { useState } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { useMutation } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import { amazonSearchSchema, type AmazonSearch, type ScanResult } from "@shared/schema";
import { Search, Loader2, AlertTriangle, CheckCircle2, ExternalLink, Package } from "lucide-react";

const categories = [
  "Household Cleaners",
  "Dietary Supplements", 
  "Pet Products",
  "Personal Care",
  "Home & Garden"
];

function getSeverityColor(severity: string) {
  switch (severity) {
    case "critical":
      return "bg-red-100 text-red-800 border-red-200";
    case "high":
      return "bg-orange-100 text-orange-800 border-orange-200";
    case "moderate":
      return "bg-amber-100 text-amber-800 border-amber-200";
    case "low":
      return "bg-yellow-100 text-yellow-800 border-yellow-200";
    default:
      return "bg-gray-100 text-gray-800 border-gray-200";
  }
}

export default function AmazonScanner() {
  const { toast } = useToast();
  const [scanResult, setScanResult] = useState<ScanResult | null>(null);
  const [isScanning, setIsScanning] = useState(false);

  const form = useForm<AmazonSearch>({
    resolver: zodResolver(amazonSearchSchema),
    defaultValues: {
      keywords: "",
      category: "all",
      maxResults: 10
    }
  });

  const scanMutation = useMutation({
    mutationFn: async (searchParams: AmazonSearch) => {
      const response = await apiRequest("POST", "/api/scan", searchParams);
      return await response.json();
    },
    onSuccess: (result: ScanResult) => {
      setScanResult(result);
      setIsScanning(false);
      toast({
        title: "Amazon Scan Complete",
        description: `Found ${result.summary.totalFlagged} products with violations out of ${result.summary.totalScanned} scanned`,
      });
    },
    onError: (error: Error) => {
      setIsScanning(false);
      toast({
        title: "Scan Failed",
        description: error.message || "Failed to scan Amazon listings. Please try again.",
        variant: "destructive",
      });
    }
  });

  const onSubmit = (data: AmazonSearch) => {
    setIsScanning(true);
    setScanResult(null);
    
    // Convert "all" back to empty string for the API
    const searchParams = {
      ...data,
      category: data.category === "all" ? "" : data.category
    };
    
    scanMutation.mutate(searchParams);
  };

  return (
    <div className="bg-slate-50 min-h-screen">
      {/* Header */}
      <header className="bg-white shadow-sm border-b border-slate-200">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <div className="flex items-center">
              <div className="flex-shrink-0">
                <h1 className="text-xl font-bold text-brand-slate">Amazon Compliance Scanner</h1>
              </div>
            </div>
            <div className="flex items-center space-x-4">
              <span className="text-sm text-slate-500">Real-time Amazon analysis</span>
              <div className="w-8 h-8 bg-slate-300 rounded-full flex items-center justify-center">
                <span className="text-sm font-medium text-slate-700">AS</span>
              </div>
            </div>
          </div>
        </div>
      </header>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Search Form */}
          <div className="lg:col-span-1">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center">
                  <Search className="h-5 w-5 mr-2 text-brand-blue" />
                  Amazon Search
                </CardTitle>
                <CardDescription>
                  Search Amazon for products and scan them for compliance violations
                </CardDescription>
              </CardHeader>
              <CardContent>
                <Form {...form}>
                  <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
                    {/* Keywords */}
                    <FormField
                      control={form.control}
                      name="keywords"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Search Keywords</FormLabel>
                          <FormControl>
                            <Input 
                              {...field}
                              placeholder="e.g., disinfectant spray, supplements..."
                              className="border-slate-300 focus:border-brand-blue focus:ring-brand-blue"
                            />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />

                    {/* Category Filter */}
                    <FormField
                      control={form.control}
                      name="category"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Category Filter (Optional)</FormLabel>
                          <Select onValueChange={field.onChange} value={field.value}>
                            <FormControl>
                              <SelectTrigger className="bg-white border-slate-300 focus:border-brand-blue focus:ring-brand-blue">
                                <SelectValue placeholder="All categories" />
                              </SelectTrigger>
                            </FormControl>
                            <SelectContent>
                              <SelectItem value="all">All categories</SelectItem>
                              {categories.map((category) => (
                                <SelectItem key={category} value={category}>
                                  {category}
                                </SelectItem>
                              ))}
                            </SelectContent>
                          </Select>
                          <FormMessage />
                        </FormItem>
                      )}
                    />

                    {/* Max Results */}
                    <FormField
                      control={form.control}
                      name="maxResults"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Maximum Results</FormLabel>
                          <Select onValueChange={(value) => field.onChange(parseInt(value))} value={field.value?.toString()}>
                            <FormControl>
                              <SelectTrigger className="bg-white border-slate-300 focus:border-brand-blue focus:ring-brand-blue">
                                <SelectValue placeholder="10" />
                              </SelectTrigger>
                            </FormControl>
                            <SelectContent>
                              <SelectItem value="5">5 products</SelectItem>
                              <SelectItem value="10">10 products</SelectItem>
                              <SelectItem value="20">20 products</SelectItem>
                              <SelectItem value="30">30 products</SelectItem>
                            </SelectContent>
                          </Select>
                          <FormMessage />
                        </FormItem>
                      )}
                    />

                    <Button
                      type="submit"
                      disabled={isScanning}
                      className="w-full bg-brand-blue hover:bg-blue-600 text-white font-medium"
                    >
                      {isScanning ? (
                        <>
                          <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                          Scanning Amazon...
                        </>
                      ) : (
                        <>
                          <Search className="h-4 w-4 mr-2" />
                          Start Scan
                        </>
                      )}
                    </Button>
                  </form>
                </Form>
              </CardContent>
            </Card>

            {/* Scanning Status */}
            {isScanning && (
              <Card className="mt-6">
                <CardContent className="pt-6">
                  <div className="flex items-center">
                    <Loader2 className="h-5 w-5 animate-spin text-brand-blue mr-3" />
                    <div>
                      <p className="text-sm font-medium text-slate-900">Scanning in progress...</p>
                      <p className="text-xs text-slate-500">This may take a few minutes</p>
                    </div>
                  </div>
                </CardContent>
              </Card>
            )}
          </div>

          {/* Scan Results */}
          <div className="lg:col-span-2">
            {!scanResult && !isScanning && (
              <Card>
                <CardHeader>
                  <CardTitle>Scan Results</CardTitle>
                  <CardDescription>Amazon compliance violations will appear here</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="text-center py-12">
                    <Package className="h-12 w-12 text-slate-300 mx-auto mb-4" />
                    <p className="text-slate-500">No scan results yet. Enter search terms to get started.</p>
                  </div>
                </CardContent>
              </Card>
            )}

            {isScanning && (
              <Card>
                <CardHeader>
                  <CardTitle>Scan Results</CardTitle>
                  <CardDescription>Analyzing Amazon listings...</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="text-center py-12">
                    <div className="animate-spin rounded-full h-12 w-12 border-2 border-brand-blue border-t-transparent mx-auto mb-4"></div>
                    <p className="text-slate-500">Scanning Amazon listings for compliance violations...</p>
                  </div>
                </CardContent>
              </Card>
            )}

            {scanResult && (
              <div className="space-y-6">
                {/* Summary Card */}
                <Card>
                  <CardHeader>
                    <CardTitle className="flex items-center justify-between">
                      Scan Summary
                      <div className="flex items-center space-x-2">
                        <div className={`w-3 h-3 rounded-full ${scanResult.summary.totalFlagged > 0 ? 'bg-red-500' : 'bg-green-500'}`}></div>
                        <span className="text-sm text-slate-600">
                          {scanResult.summary.totalFlagged} of {scanResult.summary.totalScanned} products flagged
                        </span>
                      </div>
                    </CardTitle>
                    <CardDescription>
                      Search: "{scanResult.searchQuery}" • {scanResult.totalProducts} products found
                    </CardDescription>
                  </CardHeader>
                  <CardContent>
                    {scanResult.summary.totalFlagged > 0 ? (
                      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                        {scanResult.summary.criticalViolations > 0 && (
                          <div className="bg-red-50 border border-red-200 rounded-lg p-3 text-center">
                            <div className="text-2xl font-bold text-red-600">{scanResult.summary.criticalViolations}</div>
                            <div className="text-sm text-red-700 font-medium">Critical</div>
                          </div>
                        )}
                        {scanResult.summary.highViolations > 0 && (
                          <div className="bg-orange-50 border border-orange-200 rounded-lg p-3 text-center">
                            <div className="text-2xl font-bold text-orange-600">{scanResult.summary.highViolations}</div>
                            <div className="text-sm text-orange-700 font-medium">High</div>
                          </div>
                        )}
                        {scanResult.summary.moderateViolations > 0 && (
                          <div className="bg-amber-50 border border-amber-200 rounded-lg p-3 text-center">
                            <div className="text-2xl font-bold text-amber-600">{scanResult.summary.moderateViolations}</div>
                            <div className="text-sm text-amber-700 font-medium">Moderate</div>
                          </div>
                        )}
                        {scanResult.summary.lowViolations > 0 && (
                          <div className="bg-yellow-50 border border-yellow-200 rounded-lg p-3 text-center">
                            <div className="text-2xl font-bold text-yellow-600">{scanResult.summary.lowViolations}</div>
                            <div className="text-sm text-yellow-700 font-medium">Low</div>
                          </div>
                        )}
                      </div>
                    ) : (
                      <div className="bg-green-50 border border-green-200 rounded-lg p-4 flex items-center">
                        <CheckCircle2 className="w-5 h-5 text-green-500 mr-2" />
                        <span className="font-medium text-green-800">All scanned products appear compliant</span>
                      </div>
                    )}
                  </CardContent>
                </Card>

                {/* Flagged Products */}
                {scanResult.flaggedProducts.map((flaggedProduct, index) => (
                  <Card key={index} className="border-l-4 border-red-500">
                    <CardHeader>
                      <CardTitle className="flex items-start justify-between">
                        <div className="flex-1">
                          <h3 className="text-lg font-semibold text-slate-900 mb-2">
                            {flaggedProduct.product.title}
                          </h3>
                          <div className="flex items-center space-x-2">
                            <Badge variant="outline">ASIN: {flaggedProduct.product.asin}</Badge>
                            {flaggedProduct.product.price && (
                              <Badge variant="outline">{flaggedProduct.product.price}</Badge>
                            )}
                            <a 
                              href={flaggedProduct.product.url} 
                              target="_blank" 
                              rel="noopener noreferrer"
                              className="text-brand-blue hover:text-blue-600"
                            >
                              <ExternalLink className="h-4 w-4" />
                            </a>
                          </div>
                        </div>
                        <div className="text-right">
                          <div className="text-2xl font-bold text-red-600">
                            {flaggedProduct.analysis.summary.total}
                          </div>
                          <div className="text-sm text-red-700">violations</div>
                        </div>
                      </CardTitle>
                    </CardHeader>
                    <CardContent>
                      <div className="space-y-4">
                        {/* Violation Summary */}
                        <div className="flex flex-wrap gap-2">
                          {flaggedProduct.analysis.summary.critical > 0 && (
                            <Badge className={getSeverityColor("critical")}>
                              {flaggedProduct.analysis.summary.critical} Critical
                            </Badge>
                          )}
                          {flaggedProduct.analysis.summary.high > 0 && (
                            <Badge className={getSeverityColor("high")}>
                              {flaggedProduct.analysis.summary.high} High
                            </Badge>
                          )}
                          {flaggedProduct.analysis.summary.moderate > 0 && (
                            <Badge className={getSeverityColor("moderate")}>
                              {flaggedProduct.analysis.summary.moderate} Moderate
                            </Badge>
                          )}
                          {flaggedProduct.analysis.summary.low > 0 && (
                            <Badge className={getSeverityColor("low")}>
                              {flaggedProduct.analysis.summary.low} Low
                            </Badge>
                          )}
                        </div>

                        {/* Top Violations */}
                        <div className="space-y-3">
                          {flaggedProduct.analysis.violations.slice(0, 3).map((violation, vIndex) => (
                            <div key={vIndex} className="bg-slate-50 rounded-lg p-3">
                              <div className="flex items-start justify-between mb-2">
                                <Badge className={`${getSeverityColor(violation.severity)} text-xs`}>
                                  {violation.severity.toUpperCase()}
                                </Badge>
                              </div>
                              <p className="text-sm font-medium text-slate-900 mb-1">
                                {violation.rule_violated}
                              </p>
                              <p className="text-sm text-slate-600">
                                Flagged: "{violation.claim_text}"
                              </p>
                            </div>
                          ))}
                          {flaggedProduct.analysis.violations.length > 3 && (
                            <p className="text-xs text-slate-500">
                              +{flaggedProduct.analysis.violations.length - 3} more violations
                            </p>
                          )}
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}