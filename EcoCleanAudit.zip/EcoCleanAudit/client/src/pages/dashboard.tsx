import { useState, useEffect } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Loader2, Search, Filter, BarChart3, TrendingUp, Users, AlertTriangle, Zap, PlayCircle } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";

interface DashboardMetrics {
  leads: {
    total: number;
    new: number;
    audited: number;
    contacted: number;
    replied: number;
    won: number;
  };
  severity: {
    critical: number;
    high: number;
    moderate: number;
    low: number;
  };
  conversion: {
    contact_rate: number;
    reply_rate: number;
    win_rate: number;
  };
}

interface Lead {
  id: string;
  asin: string | null;
  url: string;
  title: string;
  category: string | null;
  sellerName: string | null;
  severity: "low" | "moderate" | "high" | "critical" | null;
  state: "new" | "scraped" | "audited" | "pdf_ready" | "outreach_queued" | "contacted" | "replied" | "won" | "lost";
  createdAt: string;
}

const severityColors = {
  critical: "bg-red-100 text-red-800 border-red-200",
  high: "bg-orange-100 text-orange-800 border-orange-200",
  moderate: "bg-yellow-100 text-yellow-800 border-yellow-200",
  low: "bg-green-100 text-green-800 border-green-200",
};

const stateColors = {
  new: "bg-blue-100 text-blue-800",
  scraped: "bg-purple-100 text-purple-800",
  audited: "bg-indigo-100 text-indigo-800",
  pdf_ready: "bg-cyan-100 text-cyan-800",
  outreach_queued: "bg-yellow-100 text-yellow-800",
  contacted: "bg-orange-100 text-orange-800",
  replied: "bg-green-100 text-green-800",
  won: "bg-emerald-100 text-emerald-800",
  lost: "bg-red-100 text-red-800",
};

export default function Dashboard() {
  const [searchKeywords, setSearchKeywords] = useState("");
  const [automatedScanKeywords, setAutomatedScanKeywords] = useState("");
  const [filters, setFilters] = useState({
    severity: "",
    category: "",
    state: "",
    page: 1,
  });

  const queryClient = useQueryClient();
  const { toast } = useToast();

  // Fetch dashboard metrics
  const { data: metrics, isLoading: metricsLoading } = useQuery({
    queryKey: ["/api/dashboard/metrics"],
    queryFn: async () => {
      const response = await apiRequest("/api/dashboard/metrics");
      return response.data as DashboardMetrics;
    },
  });

  // Fetch leads
  const { data: leadsData, isLoading: leadsLoading } = useQuery({
    queryKey: ["/api/leads", filters],
    queryFn: async () => {
      const params = new URLSearchParams();
      if (filters.severity) params.append("severity", filters.severity);
      if (filters.category) params.append("category", filters.category);
      if (filters.state) params.append("state", filters.state);
      params.append("page", filters.page.toString());
      params.append("limit", "20");

      const response = await apiRequest(`/api/leads?${params.toString()}`);
      return response;
    },
  });

  // Lead discovery mutation
  const discoverLeadsMutation = useMutation({
    mutationFn: async (params: { keywords: string; category?: string; maxResults?: number }) => {
      return apiRequest("/api/leads/discover", "POST", params);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/leads"] });
      queryClient.invalidateQueries({ queryKey: ["/api/dashboard/metrics"] });
    },
  });

  const handleDiscoverLeads = () => {
    if (!searchKeywords.trim()) return;
    
    discoverLeadsMutation.mutate({
      keywords: searchKeywords,
      maxResults: 20,
    });
  };

  const MetricCard = ({ title, value, description, icon: Icon, trend }: {
    title: string;
    value: number | string;
    description: string;
    icon: any;
    trend?: number;
  }) => (
    <Card>
      <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
        <CardTitle className="text-sm font-medium">{title}</CardTitle>
        <Icon className="h-4 w-4 text-muted-foreground" />
      </CardHeader>
      <CardContent>
        <div className="text-2xl font-bold">{value}</div>
        <p className="text-xs text-muted-foreground flex items-center">
          {trend && (
            <TrendingUp className="h-3 w-3 mr-1 text-green-500" />
          )}
          {description}
        </p>
      </CardContent>
    </Card>
  );

  if (metricsLoading) {
    return (
      <div className="flex items-center justify-center h-screen">
        <Loader2 className="h-8 w-8 animate-spin" />
      </div>
    );
  }

  return (
    <div className="container mx-auto p-6 space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">Compliance Dashboard</h1>
          <p className="text-muted-foreground">
            Monitor and manage marketplace compliance leads
          </p>
        </div>
        
        <div className="flex items-center space-x-4">
          <div className="flex items-center space-x-2">
            <Input
              placeholder="Search for products..."
              value={searchKeywords}
              onChange={(e) => setSearchKeywords(e.target.value)}
              className="w-64"
            />
            <Button 
              onClick={handleDiscoverLeads}
              disabled={discoverLeadsMutation.isPending || !searchKeywords.trim()}
            >
              {discoverLeadsMutation.isPending ? (
                <Loader2 className="h-4 w-4 animate-spin mr-2" />
              ) : (
                <Search className="h-4 w-4 mr-2" />
              )}
              Discover Leads
            </Button>
          </div>
        </div>
      </div>

      {/* Metrics Cards */}
      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
        <MetricCard
          title="Total Leads"
          value={metrics?.leads.total || 0}
          description="All discovered listings"
          icon={Users}
        />
        <MetricCard
          title="Critical Issues"
          value={metrics?.severity.critical || 0}
          description="High-risk violations"
          icon={AlertTriangle}
        />
        <MetricCard
          title="Contact Rate"
          value={`${Math.round((metrics?.conversion.contact_rate || 0) * 100)}%`}
          description="Leads successfully contacted"
          icon={TrendingUp}
        />
        <MetricCard
          title="Win Rate"
          value={`${Math.round((metrics?.conversion.win_rate || 0) * 100)}%`}
          description="Contacted leads converted"
          icon={BarChart3}
        />
      </div>

      <Tabs defaultValue="leads" className="space-y-4">
        <TabsList>
          <TabsTrigger value="leads">Leads</TabsTrigger>
          <TabsTrigger value="pipeline">Pipeline</TabsTrigger>
          <TabsTrigger value="outreach">Outreach</TabsTrigger>
        </TabsList>

        <TabsContent value="leads" className="space-y-4">
          {/* Filters */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center">
                <Filter className="h-4 w-4 mr-2" />
                Filters
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="flex items-center space-x-4">
                <Select 
                  value={filters.severity} 
                  onValueChange={(value) => setFilters(prev => ({ ...prev, severity: value, page: 1 }))}
                >
                  <SelectTrigger className="w-40">
                    <SelectValue placeholder="Severity" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">All Severities</SelectItem>
                    <SelectItem value="critical">Critical</SelectItem>
                    <SelectItem value="high">High</SelectItem>
                    <SelectItem value="moderate">Moderate</SelectItem>
                    <SelectItem value="low">Low</SelectItem>
                  </SelectContent>
                </Select>

                <Select 
                  value={filters.state} 
                  onValueChange={(value) => setFilters(prev => ({ ...prev, state: value, page: 1 }))}
                >
                  <SelectTrigger className="w-40">
                    <SelectValue placeholder="State" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">All States</SelectItem>
                    <SelectItem value="new">New</SelectItem>
                    <SelectItem value="audited">Audited</SelectItem>
                    <SelectItem value="contacted">Contacted</SelectItem>
                    <SelectItem value="replied">Replied</SelectItem>
                    <SelectItem value="won">Won</SelectItem>
                  </SelectContent>
                </Select>

                {(filters.severity || filters.state) && (
                  <Button 
                    variant="outline" 
                    onClick={() => setFilters({ severity: "", category: "", state: "", page: 1 })}
                  >
                    Clear Filters
                  </Button>
                )}
              </div>
            </CardContent>
          </Card>

          {/* Leads Table */}
          <Card>
            <CardHeader>
              <CardTitle>Leads ({leadsData?.pagination?.total || 0})</CardTitle>
              <CardDescription>
                Marketplace listings with potential compliance issues
              </CardDescription>
            </CardHeader>
            <CardContent>
              {leadsLoading ? (
                <div className="flex items-center justify-center py-8">
                  <Loader2 className="h-6 w-6 animate-spin" />
                </div>
              ) : (
                <div className="space-y-4">
                  {leadsData?.data?.map((lead: Lead) => (
                    <div key={lead.id} className="border rounded-lg p-4 hover:bg-gray-50 transition-colors">
                      <div className="flex items-start justify-between">
                        <div className="space-y-2 flex-1">
                          <div className="flex items-center space-x-2">
                            <h3 className="font-medium text-sm leading-tight line-clamp-2">
                              {lead.title}
                            </h3>
                            {lead.severity && (
                              <Badge className={severityColors[lead.severity]}>
                                {lead.severity.toUpperCase()}
                              </Badge>
                            )}
                          </div>
                          
                          <div className="flex items-center space-x-4 text-sm text-muted-foreground">
                            {lead.asin && <span>ASIN: {lead.asin}</span>}
                            {lead.category && <span>Category: {lead.category}</span>}
                            {lead.sellerName && <span>Seller: {lead.sellerName}</span>}
                          </div>
                        </div>
                        
                        <div className="flex items-center space-x-2">
                          <Badge className={stateColors[lead.state]}>
                            {lead.state.replace('_', ' ').toUpperCase()}
                          </Badge>
                          
                          <Button variant="outline" size="sm" asChild>
                            <a href={`/leads/${lead.id}`}>View Details</a>
                          </Button>
                        </div>
                      </div>
                    </div>
                  ))}

                  {leadsData?.data?.length === 0 && (
                    <div className="text-center py-8 text-muted-foreground">
                      No leads found. Try discovering new leads with the search above.
                    </div>
                  )}
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="pipeline">
          <Card>
            <CardHeader>
              <CardTitle>Pipeline Overview</CardTitle>
              <CardDescription>Lead progression through compliance workflow</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="grid gap-4 md:grid-cols-3">
                <div className="space-y-2">
                  <h4 className="font-medium">Discovery & Analysis</h4>
                  <div className="space-y-1 text-sm">
                    <div className="flex justify-between">
                      <span>New Leads</span>
                      <span className="font-medium">{metrics?.leads.new || 0}</span>
                    </div>
                    <div className="flex justify-between">
                      <span>Audited</span>
                      <span className="font-medium">{metrics?.leads.audited || 0}</span>
                    </div>
                  </div>
                </div>

                <div className="space-y-2">
                  <h4 className="font-medium">Outreach</h4>
                  <div className="space-y-1 text-sm">
                    <div className="flex justify-between">
                      <span>Contacted</span>
                      <span className="font-medium">{metrics?.leads.contacted || 0}</span>
                    </div>
                    <div className="flex justify-between">
                      <span>Replied</span>
                      <span className="font-medium">{metrics?.leads.replied || 0}</span>
                    </div>
                  </div>
                </div>

                <div className="space-y-2">
                  <h4 className="font-medium">Conversion</h4>
                  <div className="space-y-1 text-sm">
                    <div className="flex justify-between">
                      <span>Won</span>
                      <span className="font-medium">{metrics?.leads.won || 0}</span>
                    </div>
                    <div className="flex justify-between">
                      <span>Win Rate</span>
                      <span className="font-medium">
                        {Math.round((metrics?.conversion.win_rate || 0) * 100)}%
                      </span>
                    </div>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="outreach">
          <Card>
            <CardHeader>
              <CardTitle>Outreach Performance</CardTitle>
              <CardDescription>Email campaign effectiveness</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="grid gap-4 md:grid-cols-2">
                <div className="space-y-4">
                  <h4 className="font-medium">Metrics</h4>
                  <div className="space-y-2 text-sm">
                    <div className="flex justify-between">
                      <span>Contact Rate</span>
                      <span className="font-medium">
                        {Math.round((metrics?.conversion.contact_rate || 0) * 100)}%
                      </span>
                    </div>
                    <div className="flex justify-between">
                      <span>Reply Rate</span>
                      <span className="font-medium">
                        {Math.round((metrics?.conversion.reply_rate || 0) * 100)}%
                      </span>
                    </div>
                  </div>
                </div>

                <div className="space-y-4">
                  <h4 className="font-medium">Severity Breakdown</h4>
                  <div className="space-y-2 text-sm">
                    <div className="flex justify-between">
                      <span className="flex items-center">
                        <span className="w-2 h-2 bg-red-500 rounded-full mr-2"></span>
                        Critical
                      </span>
                      <span className="font-medium">{metrics?.severity.critical || 0}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="flex items-center">
                        <span className="w-2 h-2 bg-orange-500 rounded-full mr-2"></span>
                        High
                      </span>
                      <span className="font-medium">{metrics?.severity.high || 0}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="flex items-center">
                        <span className="w-2 h-2 bg-yellow-500 rounded-full mr-2"></span>
                        Moderate
                      </span>
                      <span className="font-medium">{metrics?.severity.moderate || 0}</span>
                    </div>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>

      {/* Discovery Success Message */}
      {discoverLeadsMutation.isSuccess && (
        <Card className="border-green-200 bg-green-50">
          <CardContent className="pt-6">
            <div className="flex items-center space-x-2 text-green-800">
              <TrendingUp className="h-4 w-4" />
              <span className="font-medium">
                {discoverLeadsMutation.data?.message}
              </span>
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  );
}