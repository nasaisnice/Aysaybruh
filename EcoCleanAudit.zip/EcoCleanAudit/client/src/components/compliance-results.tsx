import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import type { AnalysisResult, Violation } from "@shared/schema";
import { AlertCircle, CheckCircle2, Download, FileText, Mail } from "lucide-react";

interface ComplianceResultsProps {
  result: AnalysisResult | null;
  isAnalyzing: boolean;
}

function getSeverityColor(severity: string) {
  switch (severity) {
    case "critical":
      return "bg-red-100 text-red-800 border-red-200";
    case "high":
      return "bg-orange-100 text-orange-800 border-orange-200";
    case "moderate":
      return "bg-amber-100 text-amber-800 border-amber-200";
    case "low":
      return "bg-yellow-100 text-yellow-800 border-yellow-200";
    default:
      return "bg-gray-100 text-gray-800 border-gray-200";
  }
}

function getSeverityBorderColor(severity: string) {
  switch (severity) {
    case "critical":
      return "border-red-500";
    case "high":
      return "border-orange-500";
    case "moderate":
      return "border-amber-500";
    case "low":
      return "border-yellow-500";
    default:
      return "border-gray-500";
  }
}

function ViolationCard({ violation }: { violation: Violation }) {
  return (
    <div className="bg-white rounded-lg shadow-sm border border-slate-200">
      <div className={`border-l-4 ${getSeverityBorderColor(violation.severity)}`}>
        <div className="p-6">
          <div className="flex items-start justify-between mb-3">
            <div className="flex items-center">
              <Badge className={`${getSeverityColor(violation.severity)} text-xs font-semibold px-2.5 py-0.5 rounded-full uppercase`}>
                {violation.severity}
              </Badge>
            </div>
          </div>
          
          <h3 className="font-semibold text-slate-900 mb-2">{violation.rule_violated}</h3>
          
          <div className="space-y-4 text-sm">
            <div>
              <span className="font-medium text-slate-700">Violating Text:</span>
              <span className={`ml-2 px-2 py-1 rounded ${getSeverityColor(violation.severity)}`}>
                "{violation.claim_text}"
              </span>
            </div>
            
            <div>
              <span className="font-medium text-slate-700">Rule Violated:</span>
              <span className="ml-2 text-slate-600">{violation.rule_violated}</span>
            </div>
            
            <div>
              <span className="font-medium text-slate-700">Why It Fails:</span>
              <span className="ml-2 text-slate-600">{violation.why_it_fails}</span>
            </div>
            
            <div className="bg-green-50 border border-green-200 rounded-lg p-3">
              <span className="font-medium text-green-800">Suggested Fix:</span>
              <p className="text-green-700 mt-1">"{violation.corrective_copy}"</p>
            </div>
            
            <div className="bg-blue-50 border border-blue-200 rounded-lg p-3">
              <span className="font-medium text-blue-800">Required Evidence:</span>
              <p className="text-blue-700 mt-1">{violation.required_evidence_or_doc}</p>
            </div>

            {violation.suggested_label_change && (
              <div className="bg-purple-50 border border-purple-200 rounded-lg p-3">
                <span className="font-medium text-purple-800">Label Change:</span>
                <p className="text-purple-700 mt-1">{violation.suggested_label_change}</p>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}

export default function ComplianceResults({ result, isAnalyzing }: ComplianceResultsProps) {
  if (!result && !isAnalyzing) {
    return (
      <div className="space-y-6">
        <div className="bg-white rounded-lg shadow-sm border border-slate-200 p-6">
          <h2 className="text-lg font-semibold text-slate-900 mb-4">Compliance Analysis Results</h2>
          <div className="text-center py-12">
            <FileText className="h-12 w-12 text-slate-300 mx-auto mb-4" />
            <p className="text-slate-500">No analysis results yet. Submit a listing to get started.</p>
          </div>
        </div>
      </div>
    );
  }

  if (isAnalyzing) {
    return (
      <div className="space-y-6">
        <div className="bg-white rounded-lg shadow-sm border border-slate-200 p-6">
          <h2 className="text-lg font-semibold text-slate-900 mb-4">Compliance Analysis Results</h2>
          <div className="text-center py-12">
            <div className="animate-spin rounded-full h-12 w-12 border-2 border-brand-blue border-t-transparent mx-auto mb-4"></div>
            <p className="text-slate-500">Analyzing your listing...</p>
          </div>
        </div>
      </div>
    );
  }

  if (!result) return null;

  return (
    <div className="space-y-6">
      {/* Results Overview */}
      <div className="bg-white rounded-lg shadow-sm border border-slate-200 p-6">
        <div className="flex items-center justify-between mb-4">
          <h2 className="text-lg font-semibold text-slate-900">Compliance Analysis Results</h2>
          <div className="flex items-center space-x-2">
            <div className={`w-3 h-3 rounded-full ${result.summary.compliant ? 'bg-green-500' : 'bg-red-500'}`}></div>
            <span className="text-sm text-slate-600">
              {result.summary.total === 0 ? 'No violations found' : `${result.summary.total} violation${result.summary.total !== 1 ? 's' : ''} found`}
            </span>
          </div>
        </div>

        {/* Summary Cards */}
        {result.summary.total > 0 && (
          <div className="grid grid-cols-2 gap-4 mb-6">
            {result.summary.critical > 0 && (
              <div className="bg-red-50 border border-red-200 rounded-lg p-4">
                <div className="text-2xl font-bold text-red-600">{result.summary.critical}</div>
                <div className="text-sm text-red-700 font-medium">Critical</div>
              </div>
            )}
            {result.summary.high > 0 && (
              <div className="bg-orange-50 border border-orange-200 rounded-lg p-4">
                <div className="text-2xl font-bold text-orange-600">{result.summary.high}</div>
                <div className="text-sm text-orange-700 font-medium">High</div>
              </div>
            )}
            {result.summary.moderate > 0 && (
              <div className="bg-amber-50 border border-amber-200 rounded-lg p-4">
                <div className="text-2xl font-bold text-amber-600">{result.summary.moderate}</div>
                <div className="text-sm text-amber-700 font-medium">Moderate</div>
              </div>
            )}
            {result.summary.low > 0 && (
              <div className="bg-yellow-50 border border-yellow-200 rounded-lg p-4">
                <div className="text-2xl font-bold text-yellow-600">{result.summary.low}</div>
                <div className="text-sm text-yellow-700 font-medium">Low</div>
              </div>
            )}
          </div>
        )}

        {/* Overall Status */}
        <div className={`rounded-lg p-4 ${result.summary.compliant ? 'bg-green-50 border border-green-200' : 'bg-red-50 border border-red-200'}`}>
          <div className="flex items-center">
            {result.summary.compliant ? (
              <CheckCircle2 className="w-5 h-5 text-green-500 mr-2" />
            ) : (
              <AlertCircle className="w-5 h-5 text-red-500 mr-2" />
            )}
            <span className={`font-medium ${result.summary.compliant ? 'text-green-800' : 'text-red-800'}`}>
              {result.summary.compliant ? 'Compliant' : 'Non-Compliant'}
            </span>
          </div>
          <p className={`text-sm mt-2 ${result.summary.compliant ? 'text-green-700' : 'text-red-700'}`}>
            {result.summary.compliant 
              ? 'This listing meets Amazon compliance requirements.'
              : 'This listing requires immediate attention before publication on Amazon.'
            }
          </p>
        </div>
      </div>

      {/* Violation Details */}
      {result.violations.map((violation, index) => (
        <ViolationCard key={index} violation={violation} />
      ))}

      {/* Export Actions */}
      <div className="bg-white rounded-lg shadow-sm border border-slate-200 p-6">
        <h3 className="font-semibold text-slate-900 mb-4">Export Report</h3>
        <div className="flex space-x-3">
          <Button variant="outline" className="border-slate-300 text-slate-700 hover:bg-slate-50">
            <Download className="h-4 w-4 mr-2" />
            Download PDF
          </Button>
          <Button variant="outline" className="border-slate-300 text-slate-700 hover:bg-slate-50">
            <FileText className="h-4 w-4 mr-2" />
            Export JSON
          </Button>
          <Button variant="outline" className="border-slate-300 text-slate-700 hover:bg-slate-50">
            <Mail className="h-4 w-4 mr-2" />
            Email Report
          </Button>
        </div>
      </div>
    </div>
  );
}
