import { Switch, Route, Link, useLocation } from "wouter";
import { queryClient } from "./lib/queryClient";
import { QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import { Button } from "@/components/ui/button";
import ComplianceAuditor from "@/pages/compliance-auditor";
import AmazonScanner from "@/pages/amazon-scanner";
import Dashboard from "@/pages/dashboard";
import NotFound from "@/pages/not-found";
import { FileText, Search, BarChart3 } from "lucide-react";

function Navigation() {
  const [location] = useLocation();
  
  return (
    <nav className="bg-white border-b border-slate-200 shadow-sm">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center h-16">
          <div className="flex items-center space-x-8">
            <h1 className="text-xl font-bold text-brand-slate">Compliance Platform</h1>
            <div className="flex space-x-4">
              <Link href="/dashboard">
                <Button 
                  variant={location === "/dashboard" ? "default" : "ghost"}
                  className={location === "/dashboard" ? "bg-brand-blue text-white" : "text-slate-600 hover:text-slate-900"}
                >
                  <BarChart3 className="h-4 w-4 mr-2" />
                  Dashboard
                </Button>
              </Link>
              <Link href="/">
                <Button 
                  variant={location === "/" ? "default" : "ghost"}
                  className={location === "/" ? "bg-brand-blue text-white" : "text-slate-600 hover:text-slate-900"}
                >
                  <FileText className="h-4 w-4 mr-2" />
                  Manual Audit
                </Button>
              </Link>
              <Link href="/scanner">
                <Button 
                  variant={location === "/scanner" ? "default" : "ghost"}
                  className={location === "/scanner" ? "bg-brand-blue text-white" : "text-slate-600 hover:text-slate-900"}
                >
                  <Search className="h-4 w-4 mr-2" />
                  Amazon Scanner
                </Button>
              </Link>
            </div>
          </div>
          <div className="flex items-center space-x-4">
            <span className="text-sm text-slate-500">Enterprise Platform v3.0</span>
            <div className="w-8 h-8 bg-slate-300 rounded-full flex items-center justify-center">
              <span className="text-sm font-medium text-slate-700">CP</span>
            </div>
          </div>
        </div>
      </div>
    </nav>
  );
}

function Router() {
  return (
    <Switch>
      <Route path="/dashboard" component={Dashboard} />
      <Route path="/" component={ComplianceAuditor} />
      <Route path="/scanner" component={AmazonScanner} />
      <Route component={NotFound} />
    </Switch>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <Toaster />
        <Navigation />
        <Router />
      </TooltipProvider>
    </QueryClientProvider>
  );
}

export default App;
